package mokepon7;

public class MokeponDebilitatException extends Exception {
    public MokeponDebilitatException(String missatge) {
        super(missatge);
    }
}

package mokepon7;

public class MokeponMateixSexeException extends Exception {
    public MokeponMateixSexeException(String missatge) {
        super(missatge);
    }
}

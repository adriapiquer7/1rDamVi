package mokepon7;

public class MokeponJaCapturatException extends Exception {
    public MokeponJaCapturatException(String missatge) {
        super(missatge);
    }
}

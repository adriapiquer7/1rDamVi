package mokepon7;

import java.util.Random;

public class Ou {
	private String Especie;
	private TipusMokepon tipus;
	private int passesRestants;
	
	public Ou(String Especie, TipusMokepon tipus) {
		Random rand = new Random();
		this.passesRestants = rand.nextInt(5,11);
	}
	public void caminar() {
		if(this.passesRestants==0)
		{
			eclosionar();
		}
		else
		{
			this.passesRestants--;
		}
	}
	private Mokepon eclosionar() {
		Mokepon poke = new Mokepon(this.Especie, this.tipus);
		return poke;	
	}
}

package mokepon7;

public enum TipusMokepon {
	FOC, AIGUA, PLANTA
}

package mokepon7;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Mokepon7 {
	
	static Scanner sc = new Scanner(System.in); 

	public static void main(String[] args) throws MokeponJaCapturatException, IOException {
		//podem crear un nou Mokepon perque existeix la classe i ara es un nou tipus de variable
        //el new Mokepon() es el seu constructor
        Mokepon mikachu = new Mokepon();
        //podem accedir als seus atributs interns amb el punt
        mikachu.setNom("Mikachu");
        //també podem accedir als seus mètodes interns amb el punt
        mikachu.diguesNom();
        mikachu.otorgarExperiencia(101);
        
        
        Mokepon missingNo = new Mokepon();
        System.out.println(missingNo.getNom());
        Mokepon marmander = new Mokepon("Marmander");
        System.out.println(marmander.getNom()+" "+marmander.getAtk());
        Mokepon mulmasaur = new Mokepon("Mulmasaur", 5);  
        System.out.println(mulmasaur.getNom()+" "+mulmasaur.getAtk());
        
        Mokepon fonmerno = new Mokepon("fonmerno", 9, 20, 20, 20);
        System.out.println("---------------------------");
        System.out.println(fonmerno.getNom());
        System.out.println(fonmerno.getNivell());
        System.out.println(fonmerno.getHp_max());
        System.out.println(fonmerno.getHp_actual());
        System.out.println(fonmerno.getAtk());
        System.out.println(fonmerno.getDef());
        System.out.println(fonmerno.getVel());
        System.out.println(fonmerno.getExp());
        
        System.out.println("---------------------------");
        Mokepon chicopito = new Mokepon("Chicopito", TipusMokepon.PLANTA);
        System.out.println(chicopito.getNom()+" "+chicopito.getAtk());
        if(chicopito.getTipus() == TipusMokepon.PLANTA) {
            System.out.println("Chicopito es de Planta!");
        }
        
        System.out.println("---------------------------");
        Atacs llamarada = new Atacs("Llamarada", TipusMokepon.FOC);
        Atacs pistola_agua = new Atacs("Pistola agua", TipusMokepon.AIGUA);
        chicopito.afegirAtac(pistola_agua);
        chicopito.afegirAtac(llamarada);
        //printem els atacs
        for (int i = 0; i < chicopito.getAtacs().size(); i++) {
        	System.out.println(chicopito.getAtacs().get(i).nom);
		}
        fonmerno.setTipus(TipusMokepon.FOC);
        chicopito.atacar(fonmerno, 1);
        chicopito.atacar(fonmerno, 1);
        chicopito.atacar(fonmerno, 1);
        chicopito.atacar(fonmerno, 1);
        chicopito.atacar(fonmerno, 1);
        chicopito.atacar(fonmerno, 1);
        
        System.out.println("-----------------------");
        
        MokeponCapturat elMeuMikachu = new MokeponCapturat();
        System.out.println(elMeuMikachu.getNom());
        elMeuMikachu.diguesNom();
        chicopito.atacar(elMeuMikachu, 0);
        
        System.out.println("-----------------------");
        Mokepon reshiram = new Mokepon("Reshiram", TipusMokepon.FOC);
        Mokepon zekrom = new Mokepon("Zekrom", TipusMokepon.FOC);
        Mokepon tornadus = new Mokepon("Tornadus", TipusMokepon.AIGUA);
        
        zekrom = zekrom.capturar("Adria", "zek"); 
        //de esta manera, cuando creamos un objeto pokemon, capturamos ese objeto unico, y no se podra volver a capturar
        // si queremos que ek objeto pokemon siga existiendo y poder capturar varias veces ese mismo objeto(con mismas estadisticas) haremos lo siguiente:
//        MokeponCapturat reshi = new MokeponCapturat(reshiram, "Reshi", "Adrià");
//        MokeponCapturat zek = zekrom.capturar("Zek", "Adrià");
//        MokeponCapturat torni = capturar(tornadus, "Torni", "Adrià"); 
//        //como capturamos?
//        //o bien capturamos haciendo un: MokeponCapturat nom = new MokeponCapturat(pokemon, nomEntrenador, mote) 
//        //o bien, hacemos: MokeponCapturat nom = pokemon.capturar(nomEntrenador, mote)
//        //o hacemos: MokeponCapturat nom = capturar(pokemon, nomEntrenador, mote)
//        
//        System.out.println("----------------------------------");
//        Mokepon mikachu2 = new Mokepon();
//        mikachu.estatic = "hola";
//        Mokepon mulmasaur2 = new Mokepon();
//        mulmasaur.estatic = "adeu";
//        System.out.println(mikachu.estatic);
//        System.out.println(reshi.NombreMokeponsCapturats);
//        System.out.println(chicopito);
//        System.out.println(llamarada);
//        System.out.println(zek);
//        System.out.println("--------------------------");
//        
//        MokeponCapturat Adria = new MokeponCapturat("Adria", TipusMokepon.AIGUA);
//        Adria.setHp_max(100);
//        Adria.setDebilitat(true);
//        Objecte pocio = new Pocio("Pocio", 25);
//        Objecte revivir = new Reviure("revivir");
//        System.out.println(pocio);
//        pocio.utilitzar(Adria);
//        System.out.println(Adria.isDebilitat());
//        revivir.utilitzar(Adria);
//        System.out.println(Adria.isDebilitat());
//        pocio.utilitzar(Adria);
//        pocio.utilitzar(Adria);
//        pocio.obtenir(10);
//        revivir.obtenir(2);
//        System.out.println(pocio);
//        pocio.utilitzar(Adria);
//        Adria.setObjecte(revivir);
////      Adria.setObjecte(pocio);
//        Adria.utilitzaObjecte();
        System.out.println("-----------------------------------------");
        
        Mokepon prova = new Mokepon("pollica", TipusMokepon.AIGUA);
        Mokepon prova2 = new Mokepon("Pollico", TipusMokepon.AIGUA);
       
        //el try-catch té dues parts
        try {
         //intentem fer el codi en el try
         //Ou marmasaur = prova.reproduccio(prova2);   DESCOMENTAR
        //si salta una excepció al fer el codi que hi ha dintre del try, anirà a executar aquest codi, en comptes d'acabar el programa
        } catch (Exception e) {
            //Escrivim el missatge de l’excepció. El missatge és la String que hem posat en el constructor de l’excepció
            e.printStackTrace(); //para el progra,a
//          e.getMessage(); no para el programa
	  //el finally s'executa sempre, tant si ha saltat l'excepció com si no
        } finally {
            System.out.println(marmander.getNom() + "està molt cansat");
        }
        
        ArrayList<Mokepon> mokedex = new ArrayList<>();

        mokedex.add(new Mokepon("Mikachu", TipusMokepon.PLANTA));
        mokedex.add(new Mokepon("Marmander", TipusMokepon.FOC));
        mokedex.add(new Mokepon("Mulmasaur", TipusMokepon.PLANTA));
        mokedex.add(new Mokepon("Squirtle", TipusMokepon.AIGUA));
        Collections.sort(mokedex);
        
        for (Mokepon mokepon : mokedex) {
			System.out.println(mokepon);
		}
        Mokepon mokepon1 = new Mokepon("mok1", TipusMokepon.AIGUA);
        Mokepon mokepon2 = new Mokepon("mok2", TipusMokepon.PLANTA);
        Atacs llamarada2 = new Atacs("llamarada", TipusMokepon.FOC);
        Atacs conchaFilo = new Atacs ("Concha Filo", TipusMokepon.AIGUA);
        mokepon1.afegirAtac(conchaFilo);
        mokepon1.afegirAtac(llamarada2);
        mokepon2.afegirAtac(pistola_agua);
        mokepon2.afegirAtac(llamarada);
        
//      //si mokepon1 es més rapid, torna 1, si no, torna 2.
//        int torn = MokeponMesRapid(mokepon1,mokepon2);
//        boolean fi = false;
//        while(!fi) {
//                //usuari tria el numero d'atac amb un scanner
//                int numAtac = triaAtac(torn, mokepon1, mokepon2);
//                //si el torn es 1 mokepon1 ataca a mokepon2, si el torn es 2 al reves. Consulta si el mokepon atacat ha resultat debilitat, i retorna l'estat del Mokepon atacant
//                boolean debilitat = gestionarAtac(mokepon1, mokepon2, torn, numAtac);
//                //si l'altre Mokepon queda debilitat, s'acaba el combat i s'anuncia el guanyador
//                fi = fiCombat(debilitat, torn);
//                //es passa el torn al següent
//                torn = canviTorn(torn);
//        }
        
        System.out.println("-----------------------------------");
        ArrayList<MokeponCapturat> mokedex2 = new ArrayList<>();
        MokeponCapturat piplup = new MokeponCapturat("Piplup", TipusMokepon.AIGUA);
        MokeponCapturat poplio = new MokeponCapturat("Poplio", TipusMokepon.AIGUA);
        elMeuMikachu.setNom("Mikachu");
        mokedex2.add(elMeuMikachu);
        mokedex2.add(piplup);
        mokedex2.add(poplio);
        nomDeTots(mokedex);
        nomDeTots(mokedex2);
        
        System.out.println("---------------------------------");
        
        
        //afegirGimnas("INSTITUT SABADELL", "SABADELL", "MARC");
        //afegirGimnas("GIMNAS DE MERDANYOLA", "MERDANYOLA", "MISCO");
        //afegirGimnas("GIMNAS DE LA DROGA", "MIPOLLET", "MUCAS");
        //afegirGimnas("GIMNAS DE LA MORAL CORRUPTA", "EL DISC DUR DE METHAN", "METHAN");
        mostrarGimnasos();
        System.out.println("--------------------------");
        cercaLider("INSTITUT SABADELL");
        System.out.println("--------------------------");
        cercaLider("GIMNAS DE MERDANYOLA");
        System.out.println("--------------------------");
        cercaLider("GIMNAS DE LA DROGA");
        System.out.println("--------------------------");
        cercaLider("GIMNAS DE LA MORAL CORRUPTA");
        System.out.println("--------------------------");
        invictes(9);
        System.out.println("--------------------------");
        //copiaSeguretat("gimnasos.txt", "copiaGimnasos.txt");
        System.out.println("--------------------------");
        canviLider("INSTITUT SABADELL","Adria");
        
        afegeixEntrenador("Gimnàs de Mabadell" , "Albertito");
        afegeixEntrenador("Gimnàs de Mabadell", "Martita");
        
	}
	
	private static void canviLider(String nomGimnas, String nouLider) {
	    try {
	        File f1 = new File("gimnasos.txt");
	        File f2 = new File("gimnasos_temp.txt");
	        FileReader fr1 = new FileReader(f1);
	        FileWriter fw2 = new FileWriter(f2);
	        BufferedReader br1 = new BufferedReader(fr1);
	        BufferedWriter bw2 = new BufferedWriter(fw2);

	        while (br1.ready()) {
	        	String linea = br1.readLine();
	            String[] split = linea.split(";");

	            if (split[0].equals(nomGimnas)) {
	                bw2.write(split[0] + ";" + split[1] + ";" + nouLider + ";" + split[3]);
	            } else {
	                bw2.write(linea);
	            }
	            bw2.newLine();
	        }

	        br1.close();
	        bw2.close();
	        f1.delete();
	        f2.renameTo(f1);

	    } catch (FileNotFoundException e) {
	        System.out.println("El fitxer no existeix");
	        e.printStackTrace();
	    } catch (IOException e) {
	        System.out.println("Excepció general de lectura");
	        e.printStackTrace();
	        }
	}

	private static void consultaEntrenadors(String nomGimnas) {
	    try {
	        BufferedReader br = new BufferedReader(new FileReader("gimnasos.txt"));
	        String linea;

	        while ((linea = br.readLine()) != null) {
	            String[] split = linea.split(";");

	            if (split[0].equals(nomGimnas)) {
	                if (split.length <= 4) {
	                    System.out.println("No hi ha entrenadors");
	                } else {
	                    for (int i = 4; i < split.length; i++) {
	                        System.out.println(split[i]);
	                    }
	                }
	            }
	        }

	        br.close();

	    } catch (FileNotFoundException e) {
	        System.out.println("El fitxer no existeix");
	        e.printStackTrace();
	    } catch (IOException e) {
	        System.out.println("Excepció general de lectura");
	        e.printStackTrace();
	        }
	}
	private static void esborraGimnas(String nomGimnas) {
	    try {
	        File f1 = new File("gimnasos.txt");
	        File f2 = new File("temp.txt");

	        BufferedReader br = new BufferedReader(new FileReader(f1));
	        BufferedWriter bw = new BufferedWriter(new FileWriter(f2));

	        String linea;
	        while ((linea = br.readLine()) != null) {
	            String[] split = linea.split(";");

	            if (!split[0].equals(nomGimnas)) {
	                bw.write(linea);
	                bw.newLine();
	            }
	        }

	        br.close();
	        bw.close();

	        f1.delete();
	        f2.renameTo(f1);

	    } catch (FileNotFoundException e) {
	        System.out.println("El fitxer no existeix");
	        e.printStackTrace();
	    } catch (IOException e) {
	        System.out.println("Excepció general de lectura");
	        e.printStackTrace();
	        }
	}
	
	private static void afegeixEntrenador(String nomGimnas, String nomEntrenador) {
	    try {
	        File f1 = new File("gimnasos.txt");
	        File f2 = new File("temp.txt");

	        BufferedReader br = new BufferedReader(new FileReader(f1));
	        BufferedWriter bw = new BufferedWriter(new FileWriter(f2));

	        String linea;
	        while ((linea = br.readLine()) != null) {
	            String[] split = linea.split(";");

	            if (split[0].equals(nomGimnas)) {
	                int num = Integer.parseInt(split[3]);
	                num++;

	                bw.write(split[0] + ";" + split[1] + ";" + split[2] + ";" + num);

	                for (int i = 4; i < split.length; i++) {
	                    bw.write(";" + split[i]);
	                }

	                bw.write(";" + nomEntrenador);
	            } else {
	                bw.write(linea);
	            }

	            bw.newLine();
	        }

	        br.close();
	        bw.close();

	        f1.delete();
	        f2.renameTo(f1);

	    } catch (FileNotFoundException e) {
	        System.out.println("El fitxer no existeix");
	        e.printStackTrace();
	    } catch (IOException e) {
	        System.out.println("Excepció general de lectura");
	        e.printStackTrace();
	        }
	}
	private static void copiaSeguretat(String path1, String path2) {
		try {
			File f1 = new File(path2);
			FileWriter fw1 = new FileWriter(f1, true);
			BufferedWriter bw1 = new BufferedWriter(fw1);
			File f2 = new File(path1);
			FileReader fr2 = new FileReader(f2);
			BufferedReader br2 = new BufferedReader(fr2);
			while(br2.ready())
			{
				bw1.write(br2.readLine()+"\n");
			}
			bw1.flush();
			bw1.close();
			br2.close();
		}
	catch (FileNotFoundException e) {
        System.out.println("El fitxer no existeix");
        e.printStackTrace();
    } catch (IOException e) {
        System.out.println("Excepció general de lectura");
        e.printStackTrace();
        }
    }

	private static void invictes(int Victories) {
		try {
			File f = new File("gimnasos.txt");
			FileReader fr = new FileReader(f);
			BufferedReader br = new BufferedReader(fr);
			while(br.ready()) {
				String[] Split1 = br.readLine().split(";");
				int nVictories = Integer.parseInt(Split1[3]);
				if(nVictories<=Victories)
				{
					System.out.println(Split1[0]);	
				}
			}
			br.close();
        } catch (FileNotFoundException e) {
            System.out.println("El fitxer no existeix");
            e.printStackTrace();
        } catch (IOException e) {
            System.out.println("Excepció general de lectura");
            e.printStackTrace();
        }
	}

	private static void cercaLider(String nomGimnas) {
		try {
			File f = new File("gimnasos.txt");
			FileReader fr = new FileReader(f);
			BufferedReader br = new BufferedReader(fr);
			while(br.ready()) {
				String[] Split1 = br.readLine().split(";");
				if(Split1[0].equals(nomGimnas))
				{
					System.out.println(Split1[2]);	
				}
			}
			br.close();
        } catch (FileNotFoundException e) {
            System.out.println("El fitxer no existeix");
            e.printStackTrace();
        } catch (IOException e) {
            System.out.println("Excepció general de lectura");
            e.printStackTrace();
        }
	}

	private static void mostrarGimnasos() {
		try {
			File f = new File("gimnasos.txt");
			FileReader fr = new FileReader(f);
			BufferedReader br = new BufferedReader(fr);
			while(br.ready()) {
				String[] Split1 = br.readLine().split(";");
				System.out.println(Split1[0]);
			}
			br.close();
        } catch (FileNotFoundException e) {
            System.out.println("El fitxer no existeix");
            e.printStackTrace();
        } catch (IOException e) {
            System.out.println("Excepció general de lectura");
            e.printStackTrace();
        }
	}

	public static void afegirGimnas(String nomGimnas, String ciutat, String liderGimnas) throws Exception {
	    File f = new File("gimnasos.txt");
	    BufferedReader br = new BufferedReader(new FileReader(f));
	    String linea;
	    while ((linea = br.readLine()) != null) {
	        String[] split = linea.split(";");
	        if (split[0].equals(nomGimnas)) {
	            br.close();
	            throw new Exception("El gimnàs ja existeix!");
	        }
	    }
	    br.close();
	    BufferedWriter bw = new BufferedWriter(new FileWriter(f, true));
	    bw.write(nomGimnas + ";" + ciutat + ";" + liderGimnas + ";0");
	    bw.newLine();
	    bw.close();
	}
	
	public static void nomDeTots(ArrayList<? extends Mokepon> list){
		for (Mokepon mokepon : list) {
			System.out.println(mokepon.getNom());
		}
		
	}
	private static int canviTorn(int torn) {
		if(torn==1)
		{
			return 2;
		}
		else
		{
			return 1;
		}
	}
	private static boolean fiCombat(boolean debilitat, int torn) {
		if(debilitat)
		{
			System.out.println("El mokepon rival ha quedat fora de combat, ha guanyat el mokepon"+torn);
			return true;
		}
		return false;
	}
	private static boolean gestionarAtac(Mokepon mokepon1, Mokepon mokepon2, int torn, int numAtac) {
		if(torn == 1)
		{
			mokepon1.atacar(mokepon2, numAtac);
			if(mokepon2.isDebilitat())
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			mokepon2.atacar(mokepon1, numAtac);
			if(mokepon1.isDebilitat())
			{
				return true;
			}
			else
			{
				return false;
			}
		}
	}
	private static int triaAtac(int torn, Mokepon mokepon1, Mokepon mokepon2) {
		if(torn == 1)
		{
			System.out.println("Torn de " + mokepon1.getNom());
			System.out.println(mokepon1.getAtacs());
			System.out.println("Tria un atac: ");
			int numAtac = sc.nextInt();
			return numAtac-1;
		}
		else
		{
			System.out.println("Torn de "+ mokepon2.getNom());
			System.out.println(mokepon2.getAtacs());
			System.out.println("Tria un acat: ");
			int numAtac = sc.nextInt();
			return numAtac-1;
		}
	}
	private static int MokeponMesRapid(Mokepon mokepon1, Mokepon mokepon2) {
		if(mokepon1.getVel()>mokepon2.getVel())
		{
			return 1;
		}
		return 2;
	}
	static MokeponCapturat capturar(Mokepon mok, String nomEntrenador, String nomDonat)
	{
        if(!(mok instanceof MokeponCapturat)) {
        	System.out.println(mok.getNom()+" ha estat capturat!");
        	MokeponCapturat poke = new MokeponCapturat(mok, nomEntrenador, nomDonat);
        	return poke;
        }else{
            System.out.println("No pots capturar un Mokepon que ja esta capturat");
            return (MokeponCapturat) mok;
        }
	}
}

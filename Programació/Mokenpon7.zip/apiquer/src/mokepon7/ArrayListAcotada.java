package mokepon7;

import java.util.ArrayList;

public class ArrayListAcotada<T> extends ArrayList<T> {

    @Override
    public T get(int index) {

        if(index < 0){
            return super.get(0);
        }

        if(index >= super.size()){
            return super.get(super.size() - 1);
        }

        return super.get(index);
    }

}
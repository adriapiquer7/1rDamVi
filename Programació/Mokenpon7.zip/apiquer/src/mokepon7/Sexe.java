package mokepon7;

public enum Sexe {
	MASCULI, FEMENI
}

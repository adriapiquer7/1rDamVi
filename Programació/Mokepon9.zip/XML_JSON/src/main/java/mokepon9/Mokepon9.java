package mokepon9;

import java.io.File;
import java.util.ArrayList;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

public class Mokepon9 {

    public static void main(String[] args) {

        ArrayList<String> locsMikachu = new ArrayList<>();
        locsMikachu.add("Ruta 1");
        locsMikachu.add("Ruta 6");
        locsMikachu.add("Bosc de Mikachus");

        ArrayList<String> locsMulmasaur = new ArrayList<>();
        locsMulmasaur.add("Ruta 2");
        locsMulmasaur.add("Ruta 4");
        locsMulmasaur.add("Bosc dels Mulmasaurs");

        Evolucions evMikachu = new Evolucions("Pitxu", "Raitxu");
        Evolucions evMulmasaur = new Evolucions("-", "Menusaur");

        Entrada e1 = new Entrada(25, "Mikachu", "Electric", 6.0, evMikachu, locsMikachu);
        Entrada e2 = new Entrada(1, "Mulmasaur", "Planta", 15.2, evMulmasaur, locsMulmasaur);

        ArrayList<Entrada> entrades = new ArrayList<>();
        entrades.add(e1);
        entrades.add(e2);

        Mokedex mdex = new Mokedex("Red", entrades);

         escriureEntrada(e1);
         llegirEntrada();

         escriureMokedex(mdex, "mokedex");
         Mokedex m = llegirMokedex("mokedex");
         System.out.println(m);

         afegirMokedex("mokedex", e2);
         modificarPes("mokedex", 25, 5.5f);
         afegirLocalitzacio("mokedex", 1, "Ruta 99");
        postEvolucio("mokedex", 25);
    }

    private static void escriureEntrada(Entrada entrada) {
        File fitxer = new File("entrada.xml");
        try {
            JAXBContext ctx = JAXBContext.newInstance(Entrada.class);
            Marshaller marshaller = ctx.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            marshaller.marshal(entrada, fitxer);
            System.out.println("Entrada escrita correctament");
        } catch (JAXBException e) {
            e.printStackTrace();
        }
    }

    private static void llegirEntrada() {
        File fitxer = new File("entrada.xml");
        try {
            JAXBContext ctx = JAXBContext.newInstance(Entrada.class);
            Unmarshaller unmarshaller = ctx.createUnmarshaller();
            Entrada e = (Entrada) unmarshaller.unmarshal(fitxer);
            System.out.println("Entrada llegida: " + e);
        } catch (JAXBException e) {
            e.printStackTrace();
        }
    }

    private static void escriureMokedex(Mokedex mdex, String nomFitxer) {
        File fitxer = new File(nomFitxer);
        try {
            JAXBContext ctx = JAXBContext.newInstance(Mokedex.class);
            Marshaller marshaller = ctx.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            marshaller.marshal(mdex, fitxer);
            System.out.println("Mokedex escrita correctament");
        } catch (JAXBException e) {
            e.printStackTrace();
        }
    }

    private static Mokedex llegirMokedex(String nomFitxer) {
        File fitxer = new File(nomFitxer);
        try {
            JAXBContext ctx = JAXBContext.newInstance(Mokedex.class);
            Unmarshaller unmarshaller = ctx.createUnmarshaller();
            Mokedex mdex = (Mokedex) unmarshaller.unmarshal(fitxer);
            return mdex;
        } catch (JAXBException e) {
            e.printStackTrace();
        }
        return null;
    }

    private static void afegirMokedex(String nomFitxer, Entrada novaEntrada) {
        Mokedex mdex = llegirMokedex(nomFitxer);
        mdex.getEntrades().add(novaEntrada);
        escriureMokedex(mdex, nomFitxer);
        System.out.println("Entrada afegida: " + novaEntrada.getNom());
    }

    private static void modificarPes(String nomFitxer, int idEntrada, float pesExtra) {
        Mokedex mdex = llegirMokedex(nomFitxer);
        boolean trobat = false;

        for (Entrada e : mdex.getEntrades()) {
            if (e.getId() == idEntrada) {
                e.setPes(e.getPes() + pesExtra);
                System.out.println("Pes de " + e.getNom() + " actualitzat a " + e.getPes());
                trobat = true;
            }
        }

        if (!trobat) {
            System.out.println("Error: no s'ha trobat cap entrada amb id " + idEntrada);
        } else {
            escriureMokedex(mdex, nomFitxer);
        }
    }

    private static void afegirLocalitzacio(String nomFitxer, int idEntrada, String novaLoc) {
        Mokedex mdex = llegirMokedex(nomFitxer);
        boolean trobat = false;

        for (Entrada e : mdex.getEntrades()) {
            if (e.getId() == idEntrada) {
                e.getLocalitzacions().add(novaLoc);
                System.out.println("Localitzacio '" + novaLoc + "' afegida a " + e.getNom());
                trobat = true;
            }
        }

        if (!trobat) {
            System.out.println("Error: no s'ha trobat cap entrada amb id " + idEntrada);
        } else {
            escriureMokedex(mdex, nomFitxer);
        }
    }

    private static void postEvolucio(String nomFitxer, int idEntrada) {
        Mokedex mdex = llegirMokedex(nomFitxer);
        boolean trobat = false;

        for (Entrada e : mdex.getEntrades()) {
            if (e.getId() == idEntrada) {
                String post = e.getEvolucions().getPost_evolucio();
                if (post.equals("-")) {
                    System.out.println(e.getNom() + " no té post-evolució");
                } else {
                    System.out.println("La post-evolució de " + e.getNom() + " és " + post);
                }
                trobat = true;
            }
        }

        if (!trobat) {
            System.out.println("Error: no s'ha trobat cap entrada amb id " + idEntrada);
        }
    }
}
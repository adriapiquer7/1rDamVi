package mokepon6;

import mokeponObjectes.Objecte;

public class Armadura extends Objecte implements Equipament {
	
	private int defExtra;
	
	public Armadura(String nom, int defensaExtra) {
		super(nom);
		this.defExtra = defensaExtra;
	}

	@Override
	public void equipar(MokeponCapturat mok) {
		mok.setObjecteEquipat(this);
		mok.setDef(mok.getDef()+this.defExtra);
	}

	@Override
	public void desequipar(MokeponCapturat mok) {
		mok.setObjecteEquipat(null);
		mok.setDef(mok.getDef()-this.defExtra);
	}

	@Override
	public void utilitzar(Mokepon mok) {
		equipar((MokeponCapturat) mok);
	}

}

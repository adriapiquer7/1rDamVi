package mokepon6;

public enum Sexe {
	MASCULI, FEMENI
}

package mokepon6;

public enum TipusMokepon {
	FOC, AIGUA, PLANTA
}

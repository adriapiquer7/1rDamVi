package mokepon6;

public interface Equipament {

	public abstract void equipar(MokeponCapturat mok);
	public abstract void desequipar(MokeponCapturat mok);

	public default boolean potEquipar(MokeponCapturat mok) {
		return mok.getObjecteEquipat() == null && !mok.isDebilitat();
	}

	public default boolean equipMalPosat(MokeponCapturat mok) {
		return mok.getObjecte() instanceof Equipament;
	}
}
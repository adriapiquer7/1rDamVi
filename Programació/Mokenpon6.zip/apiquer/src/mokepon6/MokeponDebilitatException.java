package mokepon6;

public class MokeponDebilitatException extends Exception {
    public MokeponDebilitatException(String missatge) {
        super(missatge);
    }
}

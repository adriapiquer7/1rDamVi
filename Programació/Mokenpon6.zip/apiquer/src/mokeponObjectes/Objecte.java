package mokeponObjectes;

import mokepon6.Mokepon;
import mokepon6.MokeponCapturat;

public abstract class Objecte {
	private String nom;
	public int Quantitat;

	public String getNom() {
		return nom;
	}

	public int getQuantitat() {
		return Quantitat;
	}
	public Objecte(String nom){
		this.nom = nom;
		this.Quantitat = 1;
	}
	public void obtenir(int numObjectes) {
		this.Quantitat+=numObjectes;
		System.out.println("Has obtenido: "+this.Quantitat+" "+this.nom);
	}
	public void donar(MokeponCapturat mokepon) {
		mokepon.setObjecte(this);
	}
	//Una classe abstracta no pot instanciàrse (és a dir, no pots fer un new). Només les classes abstractes poden tenir mètodes abstractes
    
    	
    //Un mètode abstracte significa que és un mètode que no existeix però els seus fills estan obligats a implementar-lo. Fixa’t que es tanca amb punt i coma sense obrir i definir el mètode    
    public abstract void utilitzar(Mokepon mok);

	@Override
	public String toString() {
		return "Objecte [nom=" + nom + ", Quantitat=" + Quantitat + "]";
	}
}
package mokeponObjectes;

import mokepon6.Mokepon;

class Reviure extends Objecte {
    // Constructor per Reviure
    public Reviure(String nom) {
        super(nom);
    }

	public void utilitzar(Mokepon mok) {
		if(super.getQuantitat()>=1)
		{
			if(mok.isDebilitat())
			{
				mok.setDebilitat(false);
				mok.setHp_actual(1);
				super.Quantitat--;
				System.out.println("El pokemon: "+mok.getNom()+"! ha revivido!");
			}
			else
			{
				System.out.println("El pokemon: "+mok.getNom()+" ya esta vivo!");
			}
		}
		else
		{
			System.out.println("No tienes mas "+super.getNom()+"!");
		}
	}
}

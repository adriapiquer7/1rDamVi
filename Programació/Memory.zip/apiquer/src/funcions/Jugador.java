package funcions;

public class Jugador {
	
	String nom;
	int nVictories;
	int nPunts;
	
}

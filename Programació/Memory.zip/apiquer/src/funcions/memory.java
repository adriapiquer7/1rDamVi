package funcions;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.Scanner;

public class memory {

	// Scanner per llegir dades
	static Scanner sc  =  new Scanner(System.in);

	// Dos jugadors de la partida
	static Jugador jug1 = new Jugador();
	static Jugador jug2 = new Jugador();

	public static void main(String[] args) {
		
		boolean sortir = false;
		MostrarMenu();

		// Bucle principal del menu
		while(!sortir)
		{
			System.out.print("Tria una opcio: ");
			int opcio = sc.nextInt();

			switch (opcio)
			{
			case 1:
				// Reiniciem els punts al principi de cada partida
				jug1.nPunts=0;
				jug2.nPunts=0;
				jugar();
				break;

			case 2:
				// Configuracio dels jugadors
				configracio();
				break;

			case 3:
				// Mostrar victories
				victories();
				break;

			case 4:
				// Sortir del programa
				sortir=true;
				System.out.println("Has Sortit!");
				break;

			default:
				// Opcio incorrecta
				System.out.println("Tria una opcio del menu: ");
				MostrarMenu();
				break;
			}
		}	
	}
	
	private static void jugar() {

		// Comprovem si els noms dels jugadors estan posats
		if(jug1.nom==null||jug2.nom==null)
		{
			System.out.println("Primer has de configurar els jugadors!");
			configracio();
		}
		else
		{
			// Taulell real i taulell per controlar cartes trobades
			int[][] taulell = new int[4][4];
			int[][] taulellFake = new int[4][4];
			
			// Inicialitzem els dos taulells
			iniciarTaullel(taulell, taulellFake);
			
			// mirem qui comenca
			int torn;
			torn=QuiComença();
			
			boolean fi = false;

			// Bucle de la partida
			while(!fi)
			{
				for (int i = 0; i < taulell.length; i++) {
					for (int j = 0; j < taulell.length; j++) {
						System.out.print(taulell[i][j]+" ");
					}System.out.println();
				}
				if(torn==0)
				{
					// Torn del jugador 1
					System.out.println("Torn del Jugador 1");
					int[] posicions = jugada();
					comprovacio(posicions, taulell, taulellFake, torn);
					fi = Acabat(taulellFake);
					System.out.println("JUGADOR 1: TENS "+jug1.nPunts+" PUNTS");
					torn = canviDeTorn(torn, taulell, posicions);
				}
				else
				{
					// Torn del jugador 2
					System.out.println("Torn del Jugador 2");
					int[] posicions = jugada();
					comprovacio(posicions, taulell,taulellFake, torn);
					fi = Acabat(taulellFake);
					System.out.println("JUGADOR 2: TENS "+jug2.nPunts+" PUNTS");
					torn = canviDeTorn(torn, taulell, posicions);
				}
				
			}

			// Mostrar el guanyador
			guanyador();
		}
	}

	// Comprova qui ha guanyat la partida
	private static void guanyador() {
		if(jug1.nPunts>jug2.nPunts)
		{
			System.out.println("Ha guanyat: " + jug1.nom +"!");
			jug1.nVictories++;
		}
		else if(jug2.nPunts>jug1.nPunts)
		{
			System.out.println("Ha guanyat: " + jug2.nom + "!");
			jug2.nVictories++;
		}
		else
		{
			System.out.println("HI HA HAGUT UN EMPAT!");
		}
		
	}

	// Decideix si el torn canvia o no
	private static int canviDeTorn(int torn, int[][] taulell, int[] posicions) {
		if(taulell[posicions[0]][posicions[1]]==taulell[posicions[2]][posicions[3]])
		{
			// Si encerta, manté el torn
			return torn;
		}
		else
		{
			// Si falla, canvia el torn
			if (torn == 0) {
				return 1;
			} else {
				return 0;
			}
		}
	}

	// Comprova si totes les cartes ja estan trobades
	private static boolean Acabat(int[][] taulellFake) {
		int valor = 0;
		
		for (int i = 0; i < taulellFake.length; i++) {
			for (int j = 0; j < taulellFake[0].length; j++) {
				if(taulellFake[i][j]!=valor)
				{
					return false;
				}
			}
		}
		return true;
	}

	// Comprova si la jugada es valida i si es una parella
	private static void comprovacio(int[] posicions, int[][] taulell, int[][] taulellFake, int torn) {

		if(torn==0)
		{
			// Comprovacions per al jugador 1
			if(esticfora(taulell, posicions)||taulellFake[posicions[0]][posicions[1]]==0||taulellFake[posicions[2]][posicions[3]]==0||posicions[0] == posicions[2] && posicions[1] == posicions[3])
			{
				System.out.println("Aquesta eleccio no es posible, torna a triar: ");
				posicions=jugada();
				comprovacio(posicions, taulell,taulellFake, torn);
			}
			else
			{
				// Si encerta la parella
				if(taulell[posicions[0]][posicions[1]]==taulell[posicions[2]][posicions[3]])
				{
					jug1.nPunts++;
					taulellFake[posicions[0]][posicions[1]]=0;
					taulellFake[posicions[2]][posicions[3]]=0;
				}
			}
		}
		else
		{
			// Comprovacions per al jugador 2
			if(esticfora(taulell, posicions)||taulellFake[posicions[0]][posicions[1]]==0||taulellFake[posicions[2]][posicions[3]]==0||posicions[0] == posicions[2] && posicions[1] == posicions[3])
			{
				System.out.println("Aquesta eleccio no es posible, torna a triar: ");
				posicions=jugada();
				comprovacio(posicions, taulell,taulellFake, torn);
			}
			else
			{
				// Si encerta la parella
				if(taulell[posicions[0]][posicions[1]]==taulell[posicions[2]][posicions[3]])
				{
					jug2.nPunts++;
					taulellFake[posicions[0]][posicions[1]]=0;
					taulellFake[posicions[2]][posicions[3]]=0;
				}
			}
		}
	}

	// Comprova si les posicions estan fora del taulell
	private static boolean esticfora(int[][] taulell, int[] posicions) {
		if(posicions[0]>taulell.length-1||posicions[1]>taulell.length-1||posicions[2]>taulell.length-1||posicions[3]>taulell.length-1||posicions[0]<0||posicions[1]<0||posicions[2]<0||posicions[3]<0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	// Demana al jugador les posicions de les cartes
	private static int[] jugada() {
		int[] posicions = new int[4];
		System.out.println("Fila de la primera carta: ");
		posicions[0]=sc.nextInt();
		System.out.println("Columna de la primera carta: ");
		posicions[1]=sc.nextInt();
		System.out.println("Fila de la segona carta");
		posicions[2]=sc.nextInt();
		System.out.println("Columna de la segona carta: ");
		posicions[3]=sc.nextInt();
		return posicions;		
	}

	// Decideix aleatoriament qui comenca
	private static int QuiComença() {
		Random rand = new Random();
		return rand.nextInt(0, 2);
	}

	// Omple el taulell amb parelles barrejades
	private static void iniciarTaullel(int[][] taulell, int[][] taulellFake) {
		ArrayList<Integer> NumerosTaullel = new ArrayList<Integer>();

		for (int i = 1; i <= 8; i++) {
			NumerosTaullel.add(i);
			NumerosTaullel.add(i);
		}
		
		Collections.shuffle(NumerosTaullel);
		
		int index = 0;
		
		for (int i = 0; i < taulell.length; i++) {
			for (int j = 0; j < taulell[0].length; j++) {
				taulell[i][j] = NumerosTaullel.get(index);
				taulellFake[i][j] = NumerosTaullel.get(index);
				index++;
			}
		}
	}

	// Mostra les victories acumulades
	private static void victories() {
		if(jug1.nom==null||jug2.nom==null)
		{
			System.out.println("Primer has de configurar els jugadors!");
			configracio();
		}
		else
		{
			System.out.println(jug1.nom+": TENS "+ jug1.nVictories + " VICTORIES");
			System.out.println(jug2.nom+": TENS "+ jug2.nVictories + " VICTORIES");
		}
	}

	// Demana els noms dels jugadors
	private static void configracio() {
		sc.nextLine();
		System.out.println("JUGADOR 1:");
		System.out.print("Introdueix el teu nom: ");
		jug1.nom = sc.nextLine();
		
		System.out.println("JUGADOR 2:");
		System.out.print("Introdueix el teu nom: ");
		jug2.nom = sc.nextLine();
	}

	// Mostra el menu del joc
	private static void MostrarMenu() {
		System.out.println("1. JUGAR");
		System.out.println("2. CONFIGURACIO");
		System.out.println("3. VICTORIES");
		System.out.println("4. SORTIR");
	}
}

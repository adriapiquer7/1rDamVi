package Overcooked1;

public class MainOvercooked1 {
	
	public static void main(String[] args) throws InterruptedException {
		Restaurant restaurant = Restaurant.getInstance("El bistreau de DAMvi");
		restaurant.obrirRestaurant();

		Cuiner cuiner = new Cuiner("Dani",0);
		Cuiner adria = new Cuiner("Adrià", 0);
		
		Plat plat = new Plat("Pizza");
		Plat plat2 = new Plat("Macarrons");
		Plat plat3 = new Plat("gnochi");
		Plat plat4 = new Plat("espaguetis");
		
		restaurant.afegirComanda(plat);
		restaurant.afegirComanda(plat2);
		restaurant.afegirComanda(plat3);
		restaurant.afegirComanda(plat4);
		
		while(restaurant.getComandes().size()!=0) {
			adria.cuinar(restaurant.getNom());
		}

		restaurant.iniciarRentatAutomatic();
	}
}
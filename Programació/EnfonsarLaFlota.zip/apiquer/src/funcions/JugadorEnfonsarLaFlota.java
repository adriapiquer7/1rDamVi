package funcions;

public class JugadorEnfonsarLaFlota {
	String nom;
	int moviments;
}

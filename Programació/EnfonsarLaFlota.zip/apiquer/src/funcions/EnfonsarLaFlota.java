package funcions;

import java.util.Random;
import java.util.Scanner;

public class EnfonsarLaFlota {

	static Scanner sc =  new Scanner(System.in);
	static JugadorEnfonsarLaFlota jug1 = new JugadorEnfonsarLaFlota();
	static posicio posicio = new posicio();
	public static void main(String[] args) {
		
		boolean sortir = false;
		
		while(!sortir)
		{
			mostrarMenu();
			int opcio = sc.nextInt();
			
			switch(opcio)
			{
			case 1:
				jugar();
				break;
			case 2:
				configuracio();
				break;
			case 3:
				System.out.println("Has sortit!");
				sortir = true;
				break;
			}
		}

	}
	private static void jugar() {
		if(jug1.nom == null)
		{
			System.out.println("Primer has de configurar el teu jugador!");
			configuracio();
		}
		else
		{
			sc.nextLine();
			int [][] taulellJugador = new int [10][10];
			int [][] taulellMaquina = new int [10][10];
			colocarVaixells(taulellJugador, taulellMaquina);
			boolean fi = false;
			while(!fi)
			{
				System.out.println("------------------------------");
				tirada(taulellJugador, taulellMaquina);
				comprovar(taulellMaquina, taulellJugador);
				fi=acabat(taulellMaquina);

			}
			if(fi) {
			    System.out.println("HAS GUANYAT!");
			    System.out.println("Torns necessaris: " + jug1.moviments);
			}
		}
		
	}
	private static boolean acabat(int[][] taulellMaquina) {
		 for (int i = 0; i < taulellMaquina.length; i++) {
		        for (int j = 0; j < taulellMaquina[0].length; j++) {
		            if(taulellMaquina[i][j] == 1) {
		                return false;
		            }
		        }
		    }
		 return true;
	}
	private static void comprovar(int[][] taulellMaquina, int[][] taulellJugador) {
		if(taulellMaquina[posicio.fila][posicio.columna] == 1) {
	        
	        System.out.println("ENFONSAT!");
	        
	        taulellJugador[posicio.fila][posicio.columna] = 1;
	        taulellMaquina[posicio.fila][posicio.columna] = 0;
	        
	    } else {
	        
	        System.out.println("AIGUA!");
	        
	        taulellJugador[posicio.fila][posicio.columna] = -1; // -1 = aigua
	    }
	}
	private static void tirada(int[][] taulellJugador, int[][] taulellMaquina) {
		mostrarTaulell(taulellJugador);
		System.out.println("Introdueix les coordenades de la tirada!");
		separarCoordenades();
		if(posicio.fila>=taulellMaquina.length || posicio.fila<0 || posicio.columna>=taulellMaquina[0].length|| posicio.columna<0)
		{
			System.out.println("Aquesta posicio no es posible, torna a tirar: ");
			tirada(taulellJugador, taulellMaquina);
		}
		else if(taulellJugador[posicio.fila][posicio.columna]==1||taulellJugador[posicio.fila][posicio.columna]==-1)
		{
			System.out.println("Aquesta opcio ja ha estat triada, torna a tirar: ");
			tirada(taulellJugador, taulellMaquina);
		}
		else
		{
			jug1.moviments++;
		}
		
	}
	private static void mostrarTaulell(int[][] taulellJugador) {

	    System.out.println("  a b c d e f g h i j");

	    for (int i = 0; i < taulellJugador.length; i++) {

	        System.out.print((i+1) + " ");

	        for (int j = 0; j < taulellJugador[0].length; j++) {

	            if(taulellJugador[i][j] == 0)
	                System.out.print("~ ");   // no tirat
	            else if(taulellJugador[i][j] == 1)
	                System.out.print("X ");   // enfonsat
	            else
	                System.out.print("O ");   // aigua
	        }

	        System.out.println();
	    }
	}
	private static void colocarVaixells(int[][] taulellJugador, int[][] taulellMaquina) {
		
		Random rand = new Random();
		
		for (int i = 0; i < taulellMaquina.length; i++) {
			for (int j = 0; j < taulellMaquina[0].length; j++) {
				taulellMaquina[i][j]=0;
				taulellJugador[i][j]=0;
			}
		}
		
		for (int i = 0; i < 8; i++) {
			int filaMaquina=rand.nextInt(0,10);
			int columnaMaquina=rand.nextInt(0,10);
			boolean posicioValida = true;

			if (taulellMaquina[filaMaquina][columnaMaquina] == 1)
			{
				posicioValida = false;
			}
			if (filaMaquina > 0 && taulellMaquina[filaMaquina - 1][columnaMaquina] == 1)
			{
				posicioValida = false;
			}
			if (filaMaquina < 9 && taulellMaquina[filaMaquina + 1][columnaMaquina] == 1)
			{
				posicioValida = false;
			}
			if (columnaMaquina > 0 && taulellMaquina[filaMaquina][columnaMaquina - 1] == 1)
			{
				posicioValida = false;
			}
			if (columnaMaquina < 9 && taulellMaquina[filaMaquina][columnaMaquina + 1] == 1)
			{
				posicioValida = false;
			}
			if(columnaMaquina<9 && filaMaquina<9 && taulellMaquina[filaMaquina+1][columnaMaquina+1] == 1)
			{
				posicioValida = false;
			}
			if(columnaMaquina>0 && filaMaquina>0 && taulellMaquina[filaMaquina-1][columnaMaquina-1] == 1)
			{
				posicioValida = false;
			}
			if(columnaMaquina>0 && filaMaquina<9 && taulellMaquina[filaMaquina+1][columnaMaquina-1] == 1)
			{
				posicioValida = false;
			}
			if(columnaMaquina<9 && filaMaquina>0 && taulellMaquina[filaMaquina-1][columnaMaquina+1] == 1)
			{
				posicioValida = false;
			}
			if (posicioValida)
			{
				taulellMaquina[filaMaquina][columnaMaquina] = 1;
			} 
			else 
			{
			    i--;
			}

		}
	
	}
	private static void configuracio() {
		sc.nextLine();
		System.out.println("---CONFIGURACIÓ---");
		System.out.println("Introdueix el teu nom: ");
		jug1.nom = sc.nextLine();
	}
	private static void mostrarMenu() {
		System.out.println("1. Jugar");
		System.out.println("2. Configurar");
		System.out.println("3. Sortir");
	}
	
	public static void separarCoordenades() {
		String coordenada = sc.nextLine();
		String[] split = coordenada.split(",");
		posicio.fila = Integer.parseInt(split[0])-1;
		String sfil = split[1].toLowerCase();
		char cfil = sfil.charAt(0);
		posicio.columna = cfil - 'a';
	}
}

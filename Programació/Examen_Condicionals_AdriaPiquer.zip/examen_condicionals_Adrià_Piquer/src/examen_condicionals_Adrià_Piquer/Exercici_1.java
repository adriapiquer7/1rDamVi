package examen_condicionals_Adrià_Piquer;

import java.util.Scanner;

public class Exercici_1 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int num1=sc.nextInt();
		int num2=sc.nextInt();
		int num3=sc.nextInt();
		
		double mitjana=(num1+num2+num3)/3;
		
		if(num1==0 || num2==0 || num3==0)
		{
			System.out.println("SUSPES");
		}
		else if(mitjana>=5)
		{
			if(num1>=4 && num2>=4 && num3>=4)
			{
				System.out.println("APROVAT");
			}
			else
			{
				System.out.println("SUSPES");
			}
		}
		else if(num3==9 || num3 ==10)
		{
			System.out.println("APROVAT FINAL");
		}
		else
		{
			System.out.println("SUSPES");
		}

	}

}

package examen_condicionals_Adrià_Piquer;

import java.util.Random;

public class Exercici_4 {

	public static void main(String[] args) {
		
		Random aleatori = new Random();
		
		int num = aleatori.nextInt(0,21);
		System.out.println(num);
		
		if (num!=0)
		{
			if (num>=6)
			{
				if (num>=9)
				{
					if (num>=15)
					{
						System.out.println("PREMIUM");
					}
					else
					{
						System.out.println("ESTANDARD");
					}
				}
				else
				{
					System.out.println("BASIC");
				}
			}
			else
			{
				System.out.println("ESTANDAR AMB ANUNCIS");
			}
		}
		else
		{
			System.out.println("NOTHING");
		}
	}

}

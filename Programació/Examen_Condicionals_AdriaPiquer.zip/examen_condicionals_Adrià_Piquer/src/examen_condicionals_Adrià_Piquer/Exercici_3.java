package examen_condicionals_Adrià_Piquer;

import java.util.Scanner;

public class Exercici_3 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int dies = sc.nextInt();
		int parcial=183;
		int total=548;
		int modparcial=dies%parcial;
		int modtotal=dies%total;
		int diftotal=total-modtotal;
		int difparcial=parcial-modparcial;
		
		if (modparcial==0)
		{
			System.out.println("PARCIAL " + modparcial);
		}
		
		else if (modtotal==0)
		{
			System.out.println("TOTAL " + modtotal);
		}
		else
		{
			if(difparcial<diftotal)
			{
				System.out.println("NO " + difparcial);
			}
			else
			{
				System.out.println("NO " + diftotal);
			}
		}
		
			
		

	}

}

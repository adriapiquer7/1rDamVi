package mokepon10;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;

public class Mokepon10 {

    public static void main(String[] args) throws JsonIOException, JsonSyntaxException, IOException {

        ArrayList<String> locs = new ArrayList<>();
        locs.add("Ruta 1");
        locs.add("Ruta 3");
        locs.add("Ruta 5");

        ArrayList<String> locs2 = new ArrayList<>();
        locs2.add("Ruta 2");
        locs2.add("Ruta 4");
        locs2.add("Ruta 6");

        Evolucions ev = new Evolucions("Xarmander", "Xarizar");
        Evolucions ev2 = new Evolucions("Pitxu", "Raitxu");

        Entrada entrada = new Entrada(10, "Xarmeleon", "Foc", 34.5, ev, locs);
        Entrada entrada2 = new Entrada(25, "Picatxu", "Electric", 15.5, ev2, locs2);


        afegirMokedex("mokedex.json", entrada);
        afegirMokedex("mokedex.json", entrada2);
        gigantamaxPostEvolucio("mokedex.json", 10);
        esborrarLocalitzacio("mokedex.json", 10, "Ruta 1");
    }

    private static void afegirMokedex(String nomFitxer, Entrada novaEntrada)
            throws JsonSyntaxException, JsonIOException, IOException {

        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        Mokedex mdex = gson.fromJson(new FileReader(nomFitxer), Mokedex.class);
        mdex.getEntrades().add(novaEntrada);

        FileWriter fw = new FileWriter(nomFitxer);
        fw.append(gson.toJson(mdex));
        fw.flush();
        fw.close();
        System.out.println("Entrada " + novaEntrada.getNom() + " afegida");
    }

    private static void gigantamaxPostEvolucio(String nomFitxer, int idEntrada)
            throws JsonSyntaxException, JsonIOException, IOException {

        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        Mokedex mdex = gson.fromJson(new FileReader(nomFitxer), Mokedex.class);

        String nomPostEv = null;
        boolean trobatId = false;

        for (Entrada e : mdex.getEntrades()) {
            if (e.getId() == idEntrada) {
                trobatId = true;
                if (e.getEvolucions() != null && e.getEvolucions().getPost_evolucio() != null) {
                    nomPostEv = e.getEvolucions().getPost_evolucio();
                } else {
                    System.out.println("Aquest Mokepon no té post-evolució, no es pot fer Gigantamax");
                    return;
                }
            }
        }

        if (!trobatId) {
            System.out.println("Error: no s'ha trobat cap entrada amb id " + idEntrada);
            return;
        }

        boolean trobatPostEv = false;
        for (Entrada e : mdex.getEntrades()) {
            if (e.getNom().equals(nomPostEv)) {
                e.setPes(e.getPes() * 10);
                System.out.println(e.getNom() + " ha fet Gigantamax! Ara pesa " + e.getPes());
                trobatPostEv = true;
            }
        }

        if (!trobatPostEv) {
            System.out.println("Error: no s'ha trobat cap entrada amb el nom " + nomPostEv);
        }

        FileWriter fw = new FileWriter(nomFitxer);
        fw.append(gson.toJson(mdex));
        fw.flush();
        fw.close();
    }

    private static void esborrarLocalitzacio(String nomFitxer, int idEntrada, String loc)
            throws JsonSyntaxException, JsonIOException, IOException {

        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        Mokedex mdex = gson.fromJson(new FileReader(nomFitxer), Mokedex.class);
        boolean trobatEntrada = false;

        for (Entrada e : mdex.getEntrades()) {
            if (e.getId() == idEntrada) {
                trobatEntrada = true;
                boolean esborrat = e.getLocalitzacions().removeIf(l -> l.contains(loc));
                if (esborrat) {
                    System.out.println("Localitzacio que contenia '" + loc + "' esborrada de " + e.getNom());
                } else {
                    System.out.println("No s'ha trobat cap localitzacio que contingui '" + loc + "'");
                }
            }
        }

        if (!trobatEntrada) {
            System.out.println("Error: no s'ha trobat cap entrada amb id " + idEntrada);
        }

        FileWriter fw = new FileWriter(nomFitxer);
        fw.append(gson.toJson(mdex));
        fw.flush();
        fw.close();
    }
}
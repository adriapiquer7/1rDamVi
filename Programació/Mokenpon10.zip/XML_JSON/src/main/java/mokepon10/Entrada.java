package mokepon10;

import java.util.ArrayList;

public class Entrada {

    int id;
    private String nom;
    private String tipus;
    private double pes;
    private Evolucions evolucions;
    private ArrayList<String> localitzacions = new ArrayList<>();

    public Entrada() {
        super();
    }

    public Entrada(int id, String nom, String tipus, double pes, Evolucions evolucions, ArrayList<String> localitzacions) {
        super();
        this.id = id;
        this.nom = nom;
        this.tipus = tipus;
        this.pes = pes;
        this.evolucions = evolucions;
        this.localitzacions = localitzacions;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getTipus() {
        return tipus;
    }

    public void setTipus(String tipus) {
        this.tipus = tipus;
    }

    public double getPes() {
        return pes;
    }

    public void setPes(double pes) {
        this.pes = pes;
    }

    public Evolucions getEvolucions() {
        return evolucions;
    }

    public void setEvolucions(Evolucions evolucions) {
        this.evolucions = evolucions;
    }

    public ArrayList<String> getLocalitzacions() {
        return localitzacions;
    }

    public void setLocalitzacions(ArrayList<String> localitzacions) {
        this.localitzacions = localitzacions;
    }

    @Override
    public String toString() {
        return "Entrada{id=" + id + ", nom=" + nom + ", tipus=" + tipus +
               ", pes=" + pes + ", evolucions=" + evolucions +
               ", localitzacions=" + localitzacions + "}";
    }
}
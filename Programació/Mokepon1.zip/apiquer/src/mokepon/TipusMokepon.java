package mokepon;

public enum TipusMokepon {
	FOC, AIGUA, PLANTA
}

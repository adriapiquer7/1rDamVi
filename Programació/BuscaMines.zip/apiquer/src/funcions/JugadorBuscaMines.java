package funcions;

public class JugadorBuscaMines {
	String nom;
}

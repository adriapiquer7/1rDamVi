package funcions;

public class config {
	int mines = 5;
	int files = 5;
	int columnes = 5;
}

package funcions;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class BuscaMines {

    static Scanner sc = new Scanner(System.in);
    static ArrayList<String> guanyadors = new ArrayList<>();

    public static void main(String[] args) {

        boolean sortir = false;

        JugadorBuscaMines jugador = new JugadorBuscaMines();
        jugador.nom = "Jugador";
        config configuracio = new config();
        posicio pos = new posicio();

        while (!sortir) {

            mostrarMenu();
            int opcio = sc.nextInt();
            sc.nextLine();

            switch (opcio) {
                case 1:
                    jugarPartida(jugador, configuracio, pos);
                    break;
                case 2:
                    opcions(jugador, configuracio);
                    break;
                case 3:
                    mostrarGuanyadors();
                    break;
                case 0:
                    System.out.println("Has sortit!");
                    sortir = true;
                    break;
                default:
                    System.out.println("Opció incorrecta.");
            }
        }
    }

    private static void mostrarMenu() {
        System.out.println("--- BUSCAMINES ---");
        System.out.println("1 - Jugar");
        System.out.println("2 - Opcions");
        System.out.println("3 - Veure Guanyadors");
        System.out.println("0 - Sortir");
    }

    /**
     * Mostra el menú d'opcions i permet modificar la configuració del joc.
     *
     * Permet canviar:
     * - El nom del jugador
     * - La mida del taulell (files i columnes)
     * - El nombre de mines
     *
     * @param jugador jugador actual
     * @param configuracio configuració del taulell
     */
    private static void opcions(JugadorBuscaMines jugador, config configuracio) {

        boolean actiu = true;

        while (actiu) {
            System.out.println("--- OPCIONS ---");
            System.out.println("1 - Canviar nom");
            System.out.println("2 - Canviar mida taulell");
            System.out.println("3 - Canviar nombre de mines");
            System.out.println("0 - Sortir");

            int opcio = sc.nextInt();
            sc.nextLine();

            switch (opcio) {
                case 1:
                    System.out.println("Introdueix el teu nom:");
                    jugador.nom = sc.nextLine();
                    break;

                case 2:
                    System.out.println("Files:");
                    configuracio.files = sc.nextInt();
                    System.out.println("Columnes:");
                    configuracio.columnes = sc.nextInt();
                    break;

                case 3:
                    System.out.println("Nombre de mines:");
                    configuracio.mines = sc.nextInt();
                    break;

                case 0:
                    actiu = false;
                    break;
            }
        }
    }

    /**
     * Executa la lògica principal d'una partida.
     *
     * Inicialitza el taulell, col·loca les mines i gestiona el torn del jugador
     * fins que la partida finalitza per victòria o derrota.
     *
     * @param jugador jugador actual
     * @param configuracio configuració del taulell
     * @param pos objecte que emmagatzema la posició seleccionada
     */
    private static void jugarPartida(JugadorBuscaMines jugador, config configuracio, posicio pos) {

        int[][] camp = new int[configuracio.files][configuracio.columnes];
        int[][] mines = new int[configuracio.files][configuracio.columnes];

        inicialitzarCamp(camp);
        inicialitzarMines(mines, configuracio);

        boolean fi = true;

        while (fi) {

            visualitzarCamp(camp);

            System.out.println("Fila:");
            pos.fila = sc.nextInt();
            System.out.println("Columna:");
            pos.columna = sc.nextInt();
            sc.nextLine();

            if (esticFora(camp, pos.fila, pos.columna)) {
                System.out.println("Posició fora del taulell!");
            } else {
                if (mines[pos.fila][pos.columna] == 11) {
                    System.out.println("💣 HAS PERDUT!");
                    visualitzarCamp(mines);
                    fi = false;
                } else {
                    descobrir(pos.fila, pos.columna, camp, mines);
                    if (comprovarVictoria(camp, configuracio)) {
                        System.out.println("🎉 HAS GUANYAT!");
                        guanyadors.add(jugador.nom);
                        visualitzarCamp(mines);
                        fi = false;
                    }
                }
            }
        }
    }

    /**
     * Descobreix una casella del taulell.
     *
     * Si la casella no té mines al voltant, descobreix recursivament les caselles
     * veïnes fins que troba caselles amb mines adjacents.
     *
     * @param f fila seleccionada
     * @param c columna seleccionada
     * @param camp taulell visible del jugador
     * @param mines matriu que conté les mines
     */
    private static void descobrir(int f, int c, int[][] camp, int[][] mines) {

        if (esticFora(camp, f, c) || camp[f][c] != 9) {
            return;
        }

        int num = comptarMinesAdjacents(f, c, mines);
        camp[f][c] = num;

        if (num == 0) {
            descobrir(f - 1, c, camp, mines);
            descobrir(f + 1, c, camp, mines);
            descobrir(f, c - 1, camp, mines);
            descobrir(f, c + 1, camp, mines);
        }
    }

    /**
     * Inicialitza el taulell visible omplint-lo amb el valor 9,
     * que representa caselles ocultes.
     *
     * @param camp matriu del taulell
     */
    private static void inicialitzarCamp(int[][] camp) {
        for (int i = 0; i < camp.length; i++) {
            for (int j = 0; j < camp[0].length; j++) {
                camp[i][j] = 9;
            }
        }
    }

    /**
     * Col·loca mines aleatòriament en el taulell.
     *
     * Garanteix que no es col·loquen dues mines a la mateixa casella.
     *
     * @param mines matriu on s'emmagatzemen les mines
     * @param configuracio configuració del taulell
     */
    private static void inicialitzarMines(int[][] mines, config configuracio) {

        Random rand = new Random();
        int colocades = 0;

        while (colocades < configuracio.mines) {

            int f = rand.nextInt(configuracio.files);
            int c = rand.nextInt(configuracio.columnes);

            if (mines[f][c] != 11) {
                mines[f][c] = 11;
                colocades++;
            }
        }
    }

    /**
     * Compta el nombre de mines adjacents a una casella.
     *
     * Revisa les 8 caselles del voltant (incloent diagonals) i
     * incrementa el comptador per cada mina trobada.
     *
     * @param f fila de la casella
     * @param c columna de la casella
     * @param mines matriu de mines
     * @return nombre de mines adjacents
     */
    private static int comptarMinesAdjacents(int f, int c, int[][] mines) {

        int contador = 0;

        for (int i = -1; i <= 1; i++) {
            for (int j = -1; j <= 1; j++) {

                int nf = f + i;
                int nc = c + j;

                if (!esticFora(mines, nf, nc) && mines[nf][nc] == 11) {
                    contador++;
                }
            }
        }

        return contador;
    }

    /**
     * Comprova si el jugador ha guanyat la partida.
     *
     * La victòria es produeix quan totes les caselles ocultes restants
     * corresponen exactament a la posició de les mines.
     *
     * @param camp taulell visible del jugador
     * @param configuracio configuració del taulell
     * @return true si ha guanyat, false si la partida continua
     */
    private static boolean comprovarVictoria(int[][] camp, config configuracio) {

        int ocultes = 0;

        for (int i = 0; i < camp.length; i++) {
            for (int j = 0; j < camp[0].length; j++) {
                if (camp[i][j] == 9) {
                    ocultes++;
                }
            }
        }

        return ocultes == configuracio.mines;
    }

    /**
     * Comprova si una posició està fora dels límits del taulell.
     *
     * @param mat matriu de referència
     * @param f fila
     * @param c columna
     * @return true si està fora, false si està dins
     */
    private static boolean esticFora(int[][] mat, int f, int c) {
        return (f < 0 || c < 0 || f >= mat.length || c >= mat[0].length);
    }

    /**
     * Mostra el taulell per consola.
     *
     * Representa cada casella amb:
     * - "X" si està oculta
     * - "💣" si conté una mina
     * - El número de mines adjacents si està descoberta
     *
     * @param camp matriu del taulell a visualitzar
     */
    private static void visualitzarCamp(int[][] camp) {

        System.out.println("Taulell:");

        for (int i = 0; i < camp.length; i++) {
            for (int j = 0; j < camp[0].length; j++) {

                if (camp[i][j] == 9)
                    System.out.print("X ");
                else if (camp[i][j] == 11)
                    System.out.print("💣 ");
                else
                    System.out.print(camp[i][j] + " ");
            }
            System.out.println();
        }
    }

    /**
     * Mostra la llista de jugadors que han guanyat alguna partida.
     *
     * Si encara no hi ha guanyadors, ho indica per consola.
     */
    private static void mostrarGuanyadors() {

        System.out.println("--- GUANYADORS ---");

        if (guanyadors.isEmpty()) {
            System.out.println("Encara no hi ha guanyadors.");
        } else {
            for (String nom : guanyadors) {
                System.out.println(nom);
            }
        }
    }
}
package funcions;

public class posicio {

	int fila;
	int columna;
}

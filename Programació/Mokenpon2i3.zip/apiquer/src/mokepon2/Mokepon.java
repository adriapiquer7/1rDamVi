package mokepon2;

import java.util.ArrayList;
import java.util.Random;

public class Mokepon {
    //atributs del pokemon
    String nom;
    int nivell;
    int atk;
    int def;
    int vel;
    int exp;
    int hp_max;
    int hp_actual;
    boolean debilitat = false;
    TipusMokepon tipus;
    ArrayList<Atacs> Atacs = new ArrayList<>();
    
    public void diguesNom() {
        //per a accedir a un atribut fem this.nomDeLAtribut
        //this es una paraula especial que fa referencia a nosaltres mateixos.
        System.out.println(this.nom);
    }
    public void otorgarExperiencia(int exp_otorgada) {
		this.exp+=exp_otorgada;
		if(this.exp>100)
		{
			this.exp-=100;
			pujarNivell();
		}
	}
	public void pujarNivell() {
		Random rand = new Random();
		this.nivell++;
		this.hp_max+=rand.nextInt(0,6);
		this.atk+=rand.nextInt(0,3);
		this.def+=rand.nextInt(0,3);
		this.vel+=rand.nextInt(0,3);
	}
	//fixa't que el constuctor no té retorn, ja que el que retorna es la propia classe
    public Mokepon() {
        this.nom = "Sense definir";
        this.nivell = 1;
        this.atk = 1;
        this.def = 1;
        this.vel = 1;
        this.hp_actual = 10;
        this.hp_max = 10;
    }
    //podem crear múltiples constructors sempre que tinguin paràmetres diferents
    public Mokepon(String nom) {
        //this.nom fa referència a la variable global i nom a la local que hem passat per paràmetre
        this.nom = nom;
        this.nivell = 1;
        this.atk = 1;
        this.def = 1;
        this.vel = 1;
    }
    
    public Mokepon(String nom, int nivell) {
        //aquest constructor crida al constructor de nom primer, per això el this(nom), amb el que farà tot el que el constructor de nom digui
        this(nom);
        //podem fer fors dintre d'un constructor com si fos una funció normal
        for (int i = 1; i < nivell; i++) {
            //podem cridar a funcions de la nostra propia classe amb el this
            this.pujarNivell();
        }
    }
    
    public Mokepon(String nom, int nivell, int atk, int def, int vel) {
    	this(nom,nivell);
    	this.hp_max = nivell*10;
    	this.hp_actual=this.hp_max;
    	this.atk = atk;
    	this.def = def;
    	this.vel = vel;
    }
    
    public Mokepon(String nom, TipusMokepon tipus) {
        //this.nom fa referència a la variable global i nom a la local que hem passat per paràmetre
        this.nom = nom;
        this.nivell = 1;
        this.atk = 1;
        this.def = 1;
        this.vel = 1;
        this.tipus = tipus;
    }
    public Mokepon(String nom, TipusMokepon tipus, int nivell, int atk, int def, int vel)
    {
    	this.nom=nom;
    	this.tipus=tipus;
    	this.hp_max = nivell*10;
    	this.hp_actual=this.hp_max;
    	this.atk = atk;
    	this.def = def;
    	this.vel = vel;
    }
    
    public void afegirAtac(Atacs at) {
    	if(this.Atacs.size()<2)
    	{
    		this.Atacs.add(at);
    	}
    }
    public double efectivitat(TipusMokepon atac, TipusMokepon defensa) {
        if(atac == TipusMokepon.FOC && defensa == TipusMokepon.AIGUA ||atac == TipusMokepon.AIGUA && defensa == TipusMokepon.PLANTA ||atac == TipusMokepon.PLANTA && defensa == TipusMokepon.FOC ) {
            return 0.5;
        }else if (atac == TipusMokepon.AIGUA && defensa == TipusMokepon.FOC ||atac == TipusMokepon.FOC && defensa == TipusMokepon.PLANTA ||atac == TipusMokepon.PLANTA && defensa == TipusMokepon.AIGUA ) {
            return 2;
        }else {
            return 1;
        }        
    }
    
    public void atacar(Mokepon atacat, int num_atac) {
    	if(this.debilitat==false)
    	{
    		if(this.Atacs.get(num_atac).moviments_actuals<=0)
    		{
    			System.out.println("Ja no et queden mes moviments de: " + this.Atacs.get(num_atac).nom);
    		}
    		else
    		{
    			this.Atacs.get(num_atac).moviments_actuals--;
    			System.out.println(this.nom+" Ataca a : "+atacat.nom);
    			double dany = ((((((2 * this.nivell) / 5) + 2) * this.Atacs.get(num_atac).poder * (this.atk / atacat.def))/50) + 2) * efectivitat(this.Atacs.get(num_atac).tipus, atacat.tipus);
    			atacat.hp_actual -= (int) dany;
            	System.out.println(this.nom+" ha usado "+this.Atacs.get(num_atac).nom+" y le ha hecho "+ dany + " a " + atacat.nom+", ahora le quedan: "+atacat.hp_actual+"hp");
    		}
    	}
    	else {
    		System.out.println("El Mokepon esta debilitat i no pot atacar!");
    	}
    }
    
    public void debilitarse() {
    	if(this.hp_actual<=0)
    	{
    		this.debilitat=true;
    	}
    }
    
    public void curar() {
    	if(this.debilitat==true)
    	{
    		this.debilitat=false;
    		this.hp_actual=this.hp_max;
    	}
    }
    
    public MokeponCapturat capturar(String nomEntrenador, String nomDonat) {
        if(!(this instanceof MokeponCapturat)) {
        	System.out.println(this.nom+" ha estat capturat!");
        	MokeponCapturat poke = new MokeponCapturat(this, nomEntrenador, nomDonat);
        	return poke;
        }else{
            System.out.println("No pots capturar un Mokepon que ja esta capturat");
            return (MokeponCapturat) this;
        }
    }

}


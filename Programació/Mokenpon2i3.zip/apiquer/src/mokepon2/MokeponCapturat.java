package mokepon2;

public class MokeponCapturat extends Mokepon {    
    //posem només els atributs nous, no els de Mokepon. És a dir, posem els atributs que tindrà MokeponCapturat, però no Mokepon
    String nomPosat;
    String nomEntrenador;
    int felicitat;
    
    public MokeponCapturat() {
    	super();
        this.nomPosat="Sense definir";
        this.nomEntrenador="Sense definir";
        this.felicitat=50;
	}
    
    public MokeponCapturat(String nom, TipusMokepon tipus) {
        //cridem al constructor idèntic del pare
        super(nom, tipus);
        //la resta de variables les posem nosaltres
        this.nomPosat = nom;
        this.nomEntrenador = "Adrià";
        this.felicitat = 50;
    }
    
    public MokeponCapturat(String nom) 
    {
		super(nom);
		this.nomPosat="Sense definir";
        this.nomEntrenador="Sense definir";
        this.felicitat=50;
	}
    public MokeponCapturat(String nom, int nivell)
    {
    	super(nom, nivell);
    	this.nomPosat="Sense definir";
        this.nomEntrenador="Sense definir";
        this.felicitat=50;
    }
    
    public MokeponCapturat(String nom, int nivell, int atk, int def, int vel)
    {
    	super(nom,nivell,atk,def,vel);
    	this.nomPosat="Sense definir";
    	this.nomEntrenador="Sense definir";
    	this.felicitat=50;
    }
    
    public MokeponCapturat(Mokepon mok, String nomPosat, String nomEntrenador)
    {
    	super(mok.nom, mok.tipus, mok.def, mok.atk, mok.vel, mok.nivell);
    	this.nomPosat=nomPosat;
    	this.nomEntrenador=nomEntrenador;
    	this.felicitat=50;
    }
    public void acariciar() {
		if(this.felicitat<100)
		{
			this.felicitat+=10;
		}
	}
    
    public void atacar(Mokepon atacat, int num_atac) {
    	if(this.debilitat==false)
    	{
    		if(this.Atacs.get(num_atac).moviments_actuals<=0)
    		{
    			System.out.println("Ja no et queden mes moviments de: " + this.Atacs.get(num_atac).nom);
    		}
    		else
    		{
    			this.Atacs.get(num_atac).moviments_actuals--;
    			System.out.println(this.nom+" Ataca a : "+atacat.nom);
    			double dany = ((((((2 * this.nivell) / 5) + 2) * this.Atacs.get(num_atac).poder * (this.atk / atacat.def))/50) + 2) * super.efectivitat(this.Atacs.get(num_atac).tipus, atacat.tipus);
    			if(this.felicitat>=50)
    			{
    				dany*=1.2;
    			}
    			else
    			{
    				dany*=0.8;
    			}
    			atacat.hp_actual -= (int) dany;
            	System.out.println(this.nom+" ha usado "+this.Atacs.get(num_atac).nom+" y le ha hecho "+ dany + " a " + atacat.nom+", ahora le quedan: "+atacat.hp_actual+"hp");
    		}
    	}
    	else {
    		System.out.println("El Mokepon esta debilitat i no pot atacar!");
    	}
    }
}
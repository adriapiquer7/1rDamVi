package mokepon2;

public class Mokepon2 {

	public static void main(String[] args) {
		//podem crear un nou Mokepon perque existeix la classe i ara es un nou tipus de variable
        //el new Mokepon() es el seu constructor
        Mokepon mikachu = new Mokepon();
        //podem accedir als seus atributs interns amb el punt
        mikachu.nom = "Mikachu";
        //també podem accedir als seus mètodes interns amb el punt
        mikachu.diguesNom();
        mikachu.otorgarExperiencia(101);
        
        
        Mokepon missingNo = new Mokepon();
        System.out.println(missingNo.nom);
        Mokepon marmander = new Mokepon("Marmander");
        System.out.println(marmander.nom+" "+marmander.atk);
        Mokepon mulmasaur = new Mokepon("Mulmasaur", 5);  
        System.out.println(mulmasaur.nom+" "+mulmasaur.atk);
        
        Mokepon fonmerno = new Mokepon("fonmerno", 9, 20, 20, 20);
        System.out.println("---------------------------");
        System.out.println(fonmerno.nom);
        System.out.println(fonmerno.nivell);
        System.out.println(fonmerno.hp_max);
        System.out.println(fonmerno.hp_actual);
        System.out.println(fonmerno.atk);
        System.out.println(fonmerno.def);
        System.out.println(fonmerno.vel);
        System.out.println(fonmerno.exp);
        
        System.out.println("---------------------------");
        Mokepon chicopito = new Mokepon("Chicopito", TipusMokepon.PLANTA);
        System.out.println(chicopito.nom+" "+chicopito.atk);
        if(chicopito.tipus == TipusMokepon.PLANTA) {
            System.out.println("Chicopito es de Planta!");
        }
        
        System.out.println("---------------------------");
        Atacs llamarada = new Atacs("Llamarada", TipusMokepon.FOC);
        Atacs pistola_agua = new Atacs("Pistola agua", TipusMokepon.AIGUA);
        chicopito.afegirAtac(pistola_agua);
        chicopito.afegirAtac(llamarada);
        //printem els atacs
        for (int i = 0; i < chicopito.Atacs.size(); i++) {
        	System.out.println(chicopito.Atacs.get(i).nom);
		}
        fonmerno.tipus=TipusMokepon.FOC;
        chicopito.atacar(fonmerno, 1);
        chicopito.atacar(fonmerno, 1);
        chicopito.atacar(fonmerno, 1);
        chicopito.atacar(fonmerno, 1);
        chicopito.atacar(fonmerno, 1);
        chicopito.atacar(fonmerno, 1);
        
        System.out.println("-----------------------");
        
        MokeponCapturat elMeuMikachu = new MokeponCapturat();
        System.out.println(elMeuMikachu.nom);
        elMeuMikachu.diguesNom();
        chicopito.atacar(elMeuMikachu, 0);
        
        System.out.println("-----------------------");
        Mokepon reshiram = new Mokepon("Reshiram", TipusMokepon.FOC);
        Mokepon zekrom = new Mokepon("Zekrom", TipusMokepon.FOC);
        Mokepon tornadus = new Mokepon("Tornadus", TipusMokepon.AIGUA);
        
        MokeponCapturat reshi = new MokeponCapturat(reshiram, "Adrià", "reshi");
        MokeponCapturat zek = zekrom.capturar("Adrià", "Zek");
        MokeponCapturat torni = capturar(tornadus, "Adrià", "Torni"); 
        //como capturamos?
        //o bien capturamos haciendo un: MokeponCapturat nom = new MokeponCapturat(pokemon, nomEntrenador, mote) 
        //o bien, hacemos: MokeponCapturat nom = pokemon.capturar(nomEntrenador, mote)
        //o hacemos: MokeponCapturat nom = capturar(pokemon, nomEntrenador, mote)
        
        System.out.println("----------------------------------");
        
	}
	static MokeponCapturat capturar(Mokepon mok, String nomEntrenador, String nomDonat)
	{
        if(!(mok instanceof MokeponCapturat)) {
        	System.out.println(mok.nom+" ha estat capturat!");
        	MokeponCapturat poke = new MokeponCapturat(mok, nomEntrenador, nomDonat);
        	return poke;
        }else{
            System.out.println("No pots capturar un Mokepon que ja esta capturat");
            return (MokeponCapturat) mok;
        }
	}
}

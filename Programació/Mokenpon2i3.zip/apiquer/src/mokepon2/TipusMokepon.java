package mokepon2;

public enum TipusMokepon {
	FOC, AIGUA, PLANTA
}

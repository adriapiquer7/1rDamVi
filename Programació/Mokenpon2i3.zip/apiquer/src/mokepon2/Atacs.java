package mokepon2;

public class Atacs {
	String nom;
	double poder;  
	TipusMokepon tipus;
	int moviments_maxims;
	int moviments_actuals;
	
	
	public Atacs(String nom, double poder, TipusMokepon tipus, int moviments_maxims){
		this.nom=nom;
		this.poder=poder;
		this.tipus=tipus;
		this.moviments_maxims = moviments_maxims;
		this.moviments_actuals=this.moviments_maxims;
		if(this.poder<10)
		{
			this.poder=10;
		}
		if(this.poder>100)
		{
			this.poder=100;
		}
	}
	
	public Atacs(String nom, TipusMokepon tipus){
		this.nom = nom;
		this.tipus = tipus;
		this.poder = 10;
		this.moviments_actuals=10;
		this.moviments_maxims=10;
	}
	
}


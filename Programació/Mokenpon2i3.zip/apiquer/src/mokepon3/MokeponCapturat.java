package mokepon3;

public class MokeponCapturat extends Mokepon {    
    //posem només els atributs nous, no els de Mokepon. És a dir, posem els atributs que tindrà MokeponCapturat, però no Mokepon
	String nomPosat;
	private String nomEntrenador;
	private int felicitat;
    static int NombreMokeponsCapturats;
    public MokeponCapturat() {
    	super();
        this.nomPosat="Sense definir";
        this.nomEntrenador="Sense definir";
        this.felicitat=50;
	}
    
    public MokeponCapturat(String nom, TipusMokepon tipus) {
        //cridem al constructor idèntic del pare
        super(nom, tipus);
        //la resta de variables les posem nosaltres
        this.nomPosat = nom;
        this.nomEntrenador = "Adrià";
        this.felicitat = 50;
        NombreMokeponsCapturats++;
    }
    
    public MokeponCapturat(String nom) 
    {
		super(nom);
		this.nomPosat="Sense definir";
        this.nomEntrenador="Sense definir";
        this.felicitat=50;
        NombreMokeponsCapturats++;

	}
    public MokeponCapturat(String nom, int nivell)
    {
    	super(nom, nivell);
    	this.nomPosat="Sense definir";
        this.nomEntrenador="Sense definir";
        this.felicitat=50;
        NombreMokeponsCapturats++;

    }
    
    public MokeponCapturat(String nom, int nivell, int atk, int def, int vel)
    {
    	super(nom,nivell,atk,def,vel);
    	this.nomPosat="Sense definir";
    	this.nomEntrenador="Sense definir";
    	this.felicitat=50;
        NombreMokeponsCapturats++;

    }
    
    public MokeponCapturat(Mokepon mok, String nomPosat, String nomEntrenador)
    {
    	super(mok.getNom(), mok.getTipus(), mok.getDef(), mok.getAtk(), mok.getVel(), mok.getNivell());
    	this.nomPosat=nomPosat;
    	this.nomEntrenador=nomEntrenador;
    	this.felicitat=50;
        NombreMokeponsCapturats++;

    }
    public void acariciar() {
		if(this.felicitat<100)
		{
			this.felicitat+=10;
		}
	}
    
    public void atacar(Mokepon atacat, int num_atac) {
    	if(this.isDebilitat()==false)
    	{
    		if(this.getAtacs().get(num_atac).moviments_actuals<=0)
    		{
    			System.out.println("Ja no et queden mes moviments de: " + this.getAtacs().get(num_atac).nom);
    		}
    		else
    		{
    			this.getAtacs().get(num_atac).moviments_actuals--;
    			System.out.println(this.getNom()+" Ataca a : "+atacat.getNom());
    			double dany = ((((((2 * this.getNivell()) / 5) + 2) * this.getAtacs().get(num_atac).poder * (this.getAtk() / atacat.getDef()))/50) + 2) * super.efectivitat(this.getAtacs().get(num_atac).tipus, atacat.getTipus());
    			if(this.felicitat>=50)
    			{
    				dany*=1.2;
    			}
    			else
    			{
    				dany*=0.8;
    			}
    			atacat.setHp_actual(getHp_actual() - (int) dany); 
            	System.out.println(this.getNom()+" ha usado "+this.getAtacs().get(num_atac).nom+" y le ha hecho "+ dany + " a " + atacat.getNom()+", ahora le quedan: "+atacat.getHp_actual()+"hp");
    		}
    	}
    	else {
    		System.out.println("El Mokepon esta debilitat i no pot atacar!");
    	}
    }
	public String getNomPosat() {
		return nomPosat;
	}

	public String getNomEntrenador() {
		return nomEntrenador;
	}

	@Override
	public String toString() {
		return "MokeponCapturat [nomPosat=" + nomPosat + ", nomEntrenador=" + nomEntrenador + ", felicitat=" + felicitat
				+ "]";
	}
}
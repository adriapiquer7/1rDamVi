package mokepon3;

public class Mokepon3 {

	public static void main(String[] args) {
		//podem crear un nou Mokepon perque existeix la classe i ara es un nou tipus de variable
        //el new Mokepon() es el seu constructor
        Mokepon mikachu = new Mokepon();
        //podem accedir als seus atributs interns amb el punt
        mikachu.setNom("Mikachu");
        //també podem accedir als seus mètodes interns amb el punt
        mikachu.diguesNom();
        mikachu.otorgarExperiencia(101);
        
        
        Mokepon missingNo = new Mokepon();
        System.out.println(missingNo.getNom());
        Mokepon marmander = new Mokepon("Marmander");
        System.out.println(marmander.getNom()+" "+marmander.getAtk());
        Mokepon mulmasaur = new Mokepon("Mulmasaur", 5);  
        System.out.println(mulmasaur.getNom()+" "+mulmasaur.getAtk());
        
        Mokepon fonmerno = new Mokepon("fonmerno", 9, 20, 20, 20);
        System.out.println("---------------------------");
        System.out.println(fonmerno.getNom());
        System.out.println(fonmerno.getNivell());
        System.out.println(fonmerno.getHp_max());
        System.out.println(fonmerno.getHp_actual());
        System.out.println(fonmerno.getAtk());
        System.out.println(fonmerno.getDef());
        System.out.println(fonmerno.getVel());
        System.out.println(fonmerno.getExp());
        
        System.out.println("---------------------------");
        Mokepon chicopito = new Mokepon("Chicopito", TipusMokepon.PLANTA);
        System.out.println(chicopito.getNom()+" "+chicopito.getAtk());
        if(chicopito.getTipus() == TipusMokepon.PLANTA) {
            System.out.println("Chicopito es de Planta!");
        }
        
        System.out.println("---------------------------");
        Atacs llamarada = new Atacs("Llamarada", TipusMokepon.FOC);
        Atacs pistola_agua = new Atacs("Pistola agua", TipusMokepon.AIGUA);
        chicopito.afegirAtac(pistola_agua);
        chicopito.afegirAtac(llamarada);
        //printem els atacs
        for (int i = 0; i < chicopito.getAtacs().size(); i++) {
        	System.out.println(chicopito.getAtacs().get(i).nom);
		}
        fonmerno.setTipus(TipusMokepon.FOC);
        chicopito.atacar(fonmerno, 1);
        chicopito.atacar(fonmerno, 1);
        chicopito.atacar(fonmerno, 1);
        chicopito.atacar(fonmerno, 1);
        chicopito.atacar(fonmerno, 1);
        chicopito.atacar(fonmerno, 1);
        
        System.out.println("-----------------------");
        
        MokeponCapturat elMeuMikachu = new MokeponCapturat();
        System.out.println(elMeuMikachu.getNom());
        elMeuMikachu.diguesNom();
        chicopito.atacar(elMeuMikachu, 0);
        
        System.out.println("-----------------------");
        Mokepon reshiram = new Mokepon("Reshiram", TipusMokepon.FOC);
        Mokepon zekrom = new Mokepon("Zekrom", TipusMokepon.FOC);
        Mokepon tornadus = new Mokepon("Tornadus", TipusMokepon.AIGUA);
        
        MokeponCapturat reshi = new MokeponCapturat(reshiram, "Reshi", "Adrià");
        MokeponCapturat zek = zekrom.capturar("Zek", "Adrià");
        MokeponCapturat torni = capturar(tornadus, "Torni", "Adrià"); 
        //como capturamos?
        //o bien capturamos haciendo un: MokeponCapturat nom = new MokeponCapturat(pokemon, nomEntrenador, mote) 
        //o bien, hacemos: MokeponCapturat nom = pokemon.capturar(nomEntrenador, mote)
        //o hacemos: MokeponCapturat nom = capturar(pokemon, nomEntrenador, mote)
        
        System.out.println("----------------------------------");
        Mokepon mikachu2 = new Mokepon();
        mikachu.estatic = "hola";
        Mokepon mulmasaur2 = new Mokepon();
        mulmasaur.estatic = "adeu";
        System.out.println(mikachu.estatic);
        System.out.println(reshi.NombreMokeponsCapturats);
        System.out.println(chicopito);
        System.out.println(llamarada);
        System.out.println(zek);
	}
	static MokeponCapturat capturar(Mokepon mok, String nomEntrenador, String nomDonat)
	{
        if(!(mok instanceof MokeponCapturat)) {
        	System.out.println(mok.getNom()+" ha estat capturat!");
        	MokeponCapturat poke = new MokeponCapturat(mok, nomEntrenador, nomDonat);
        	return poke;
        }else{
            System.out.println("No pots capturar un Mokepon que ja esta capturat");
            return (MokeponCapturat) mok;
        }
	}
}

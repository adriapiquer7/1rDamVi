package mokepon3;

public enum TipusMokepon {
	FOC, AIGUA, PLANTA
}

package Overcooked2;

public class Restaurant {
    //atributs del restaurant
    private static Restaurant instance;
    private static String nom;
    private static Comandes comandes = new Comandes(); //cua
    private static PlatsBruts platsbruts = new PlatsBruts(); //pila
    
    //constructor privat de restaurant
    private Restaurant(String nom) {
		Restaurant.nom=nom;
	}
    //mètode getInstance que es cridarà des de fora i que accedirà al constructor privat
    public static Restaurant getInstance(String nom) {
		if(instance==null) {
			instance = new Restaurant(nom);
		}
		return instance;
	}
    // mètodes 
	public void obrirRestaurant() {
		System.out.println("El restaurant "+nom+" està obert!");
	}
	public static String getNom() {
		return nom;
	}
	
	public void afegirComanda(Plat p) {
		comandes.add(p);
		System.out.println("S'ha afegit la comanda del plat: "+ p.getNom());
	}
	
	public Plat servirComanda() {
		return comandes.poll();
	}
	
	public void afegirPlatBrut(Plat p) {
		platsbruts.push(p);
		System.out.println("S'ha afegit a la pila de plats bruts el plat: "+p.getNom());
	}
	
	public void iniciarRentatAutomatic() throws InterruptedException {
		while(platsbruts.size()!=0) {
			Plat plat = platsbruts.pop();
			System.out.println("S'ha netejat el plat: "+plat.getNom());
			Thread.sleep(3000);
		}
		System.out.println("La pila de plats bruts ja esta neta!");
	}
	public static Comandes getComandes() {
		return comandes;
	}

	public static PlatsBruts getPlatsbruts() {
		return platsbruts;
	}
}

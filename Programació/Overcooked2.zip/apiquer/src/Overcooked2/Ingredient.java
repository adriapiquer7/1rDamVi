package Overcooked2;

public interface Ingredient{
    String getNom();
}

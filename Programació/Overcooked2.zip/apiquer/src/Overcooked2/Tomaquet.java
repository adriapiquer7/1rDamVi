package Overcooked2;

public class Tomaquet implements Ingredient{

	@Override
	public String getNom() {
		return "tomaquet";
	}

}

package Overcooked2;

public abstract class Cuiner {
	private String nom;
	private int sexe;
	
	public Cuiner(String nom, int sexe) {
		super();
		this.nom = nom;
		this.sexe = sexe;
	}

	public void cuinar(String nomRestaurant) {
		Plat plat = Restaurant.getInstance(nom).servirComanda();
		if(this.sexe == 0)
		{
			System.out.println("El cuiner "+nom+" està cuinant "+plat.getNom());
			Restaurant.getInstance(nom).afegirPlatBrut(plat);
		}
		else
		{
			System.out.println("La cuinera "+nom+" està cuinant "+plat.getNom());
			Restaurant.getInstance(nom).afegirPlatBrut(plat);
		}
	}
	
	@Override
	public String toString() {
		return "Cuiner [nom=" + nom + ", sexe=" + sexe + "]";
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public int getSexe() {
		return sexe;
	}

	public void setSexe(int sexe) {
		this.sexe = sexe;
	}
	
}

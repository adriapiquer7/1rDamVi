package Overcooked2;

public class MainOvercooked2 {
	
	public static void main(String[] args) throws InterruptedException {
//		Restaurant restaurant = Restaurant.getInstance("El bistreau de DAMvi");
//		restaurant.obrirRestaurant();
//
//		Cuiner cuiner = new Cuiner("Dani",0);
//		Cuiner adria = new Cuiner("Adrià", 0);
//		
//		Plat plat = new Plat("Pizza");
//		Plat plat2 = new Plat("Macarrons");
//		Plat plat3 = new Plat("gnochi");
//		Plat plat4 = new Plat("espaguetis");
//		

//		
//		while(restaurant.getComandes().size()!=0) {
//			adria.cuinar(restaurant.getNom());
//		}
//
//		restaurant.iniciarRentatAutomatic();
		
//		Restaurant restaurant = Restaurant.getInstance("El bistreau de DAMvi");
//		restaurant.obrirRestaurant();
//		
//	    RestaurantFactory italiaFactory = new ItaliaFactory();
//	    Cuiner cuinerItalia = italiaFactory.crearCuiner("Dani", 0);
//	    Ingredient ingredientItalia = italiaFactory.crearIngredient();
//
//	    Plat pizza = new Plat("Pizza");
//	    // Afegim comandes
//	    restaurant.afegirComanda(pizza);
//	    cuinerItalia.cuinar(restaurant.getNom());

		
		Restaurant restaurant = Restaurant.getInstance("El segell de Can Adrià");
		restaurant.obrirRestaurant();
		
		RestaurantFactory FabricadePizzes = new ItaliaFactory();
		RestaurantFactory FabricadeSushi = new JapoFactory();
		
		Cuiner cuinerItalia = FabricadePizzes.crearCuiner("Nacho", 0);
		Cuiner cuinerJapo = FabricadeSushi.crearCuiner("Ruby", 1);
		
		PlatFactory platItalia = new PizzaFactory();
		PlatFactory platJapo = new SushiFactory();
		
		Ingredient tomaquet = FabricadePizzes.crearIngredient();
		Ingredient arros = FabricadeSushi.crearIngredient();

		Plat plat1 = platItalia.crearPlat(tomaquet);
		Plat plat2 = platJapo.crearPlat(arros);
		Plat plat3 = platItalia.crearPlat(tomaquet);
		Plat plat4 = platJapo.crearPlat(arros);

		restaurant.afegirComanda(plat1);
		restaurant.afegirComanda(plat2);
		restaurant.afegirComanda(plat3);
		restaurant.afegirComanda(plat4);
		
		while(restaurant.getComandes().size() != 0) {
			cuinerItalia.cuinar(restaurant.getNom());
			cuinerJapo.cuinar(restaurant.getNom());
		}
		
		restaurant.iniciarRentatAutomatic();
	}
}
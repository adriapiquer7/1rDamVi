package Overcooked2;

import java.util.ArrayDeque;

public class PlatsBruts extends ArrayDeque<Plat>{

	public PlatsBruts() {
		super();
	}

	@Override
	public String toString() {
		return "PlatsBruts []";
	}
}

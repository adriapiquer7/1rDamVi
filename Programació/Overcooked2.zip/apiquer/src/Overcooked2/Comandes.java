package Overcooked2;

import java.util.ArrayDeque;

public class Comandes extends ArrayDeque<Plat>{

	public Comandes() {
		super();
	}

	@Override
	public String toString() {
		return "Comandes []";
	}
}

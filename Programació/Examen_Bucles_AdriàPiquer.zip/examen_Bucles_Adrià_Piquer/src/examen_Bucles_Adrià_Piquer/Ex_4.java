package examen_Bucles_Adrià_Piquer;

import java.util.Iterator;
import java.util.Scanner;

public class Ex_4 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int r = sc.nextInt();
		int c = sc.nextInt();
		
				
		for (int i = 1; i < r; i++) {
			for (int j = 1; j < c; j++) {
				int base=(i+j)*10;
				int comptador = 0;
				comptador+=base;
				
				if((i+j)%6==0)
				{
					base=0;
					comptador+=base;
				}
				else if((i+j)%3==0)
				{
					base*=2;
					comptador+=base;
				}
				else if(comptador%4==0)
				{
					comptador+=50;
				}
				else
				{
					comptador+=base;
				}
				System.out.println(comptador);
			}
		}
		
	}

}

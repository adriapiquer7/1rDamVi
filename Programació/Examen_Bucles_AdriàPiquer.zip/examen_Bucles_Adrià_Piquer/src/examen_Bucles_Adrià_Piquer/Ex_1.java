package examen_Bucles_Adrià_Piquer;

import java.util.Scanner;

public class Ex_1 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int Dav = 5;
		int Lau = 6;
		boolean jordi = false;
		int valoracions=0;
		
		while(valoracions!=5 && Dav!=10 && Lau!=10)
		{
			String str = sc.nextLine();
			if(str.equals("LAURA"))
			{
				Lau++;
				valoracions++;
			}
			else if(str.equals("DAVID"))
			{
				Dav++;
				valoracions++;
			}
			else if (str.equals("JORDI"))
			{
				jordi = true;
				valoracions++;
			}
			
		}
		if(jordi==true)
		{
			System.out.println("GUANYA JORDI PERQUE ES EL MILLOR MASTERCHEF");
		}
		else if(Dav>Lau&&jordi==false)
		{
			System.out.println("GUANYA DAVID AMB " + Dav + " I HAN VALORAT " + valoracions + " JUTGES");
		}
		else if (Lau>Dav&&jordi==false)
		{
			System.out.println("GUANYA LAURA AMB " + Lau + " I HAN VALORAT " + valoracions + " JUTGES");
		}
		else
		{
			System.out.println("EMPAT");
		}
	}

}

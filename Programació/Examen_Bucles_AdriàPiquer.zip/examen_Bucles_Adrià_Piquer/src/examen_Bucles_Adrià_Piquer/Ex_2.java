package examen_Bucles_Adrià_Piquer;

import java.util.Scanner;

public class Ex_2 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		long capMax = sc.nextInt();
		long intervals=sc.nextInt();
		boolean err = false;
		long maxContador = 0;
		long fin = 0;
		long max = 0;
		for (int i = 0; i < intervals; i++) {
			long entrades = sc.nextInt();
			long sortides = sc.nextInt();
			max+=entrades;
			max-=sortides;
			fin+=entrades;
			fin-=sortides;
			
			if(max+entrades>max)
			{
				maxContador=max;
			}
			if(max+entrades>capMax)
			{
				err=true;
			}
			else if(fin-sortides<0)
			{
				err=true;
			}
			
			System.out.println(max);
			System.out.println(maxContador);
		}
		if(err==true)
		{
			System.out.println("ERROR");
		}
		else
		{
			System.out.println("MAX " + maxContador);
			System.out.println("FINAL " + fin);
		}

	}

}

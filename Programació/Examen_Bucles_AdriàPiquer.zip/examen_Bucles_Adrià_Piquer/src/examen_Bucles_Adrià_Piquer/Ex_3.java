package examen_Bucles_Adrià_Piquer;

import java.util.Scanner;

public class Ex_3 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		String str = sc.nextLine();
		int comptador = 0;
		for (int j = 0; j < str.length()-2; j++) {
			if(str.charAt(j)==str.charAt(j+1)&&str.charAt(j)==str.charAt(j+2))
			{
				comptador++;
			}
			System.out.println(comptador);
		}
		if(comptador==0)
		{
			System.out.println("NO HI HA REPETICIONS SOSPITOSES");
		}
		else
		{
			System.out.println();
		}
	}

}

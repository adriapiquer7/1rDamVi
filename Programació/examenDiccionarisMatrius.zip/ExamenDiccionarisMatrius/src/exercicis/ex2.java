package exercicis;

import java.util.Scanner;

public class ex2 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		String[][] mat = new String[sc.nextInt()][sc.nextInt()];
		
		for (int i = 0; i < mat.length; i++) {
			for (int j = 0; j < mat[0].length; j++) {
				mat[i][j]=sc.next();
			}
		}
		boolean fila = false;
		boolean columna = false;
		int f =sc.nextInt();
		int c = sc.nextInt();
		
		
		for (int i = 0; i < mat.length; i++) {
			if(mat[i][c].equals("u"))
			{
				if(i + 2 < mat[0].length)
				{
					if(mat[i+1][c].equals("w"))
					{
						if(mat[i+2][c].equals("u"))
						{
							columna=true;
						}
					}
				}
			}
		}
		for (int i = 0; i < mat[0].length; i++) {
			if(mat[f][i].equals("u"))
			{
				if(i + 2 < mat[0].length)
				{
					if(mat[f][i+1].equals("w"))
					{
						if(mat[f][i+2].equals("u"))
						{
							fila=true;
						}
					}
				}
			}
		}
		
		if(fila==true)
		{
			if(columna==true)
			{
				System.out.println("UWU");
			}
			else
			{
				System.out.println("uwu");
			}
		}
		else if(columna==true)
		{
			if(fila==true)
			{
				System.out.println("UWU");
			}
			else
			{
				System.out.println("uwu");
			}
		}
		else
		{
			System.out.println("uwun't");
		}
		
		
		
	}

}

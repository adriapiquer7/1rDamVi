package exercicis;

import java.util.Scanner;

public class ex3 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int[][] mat = new int[sc.nextInt()][sc.nextInt()];
		
		for (int i = 0; i < mat.length; i++) {
			for (int j = 0; j < mat[0].length; j++) {
				mat[i][j]=sc.nextInt();
			}
		}
		int f = sc.nextInt();
		int c = sc.nextInt();
		
		int amunt = 0;
		int avall = 0;
		int esq = 0;
		int dreta =0;
		int posicio = mat[f][c];
		
		if(!esticFora(mat,f,c)) //amunt
		{
			for (int i = 0; i < f; i++) {
				amunt+=mat[i][c];
			}
		}
		
		if(!esticFora(mat,f,c)) //avall
		{
			for (int i = f+1; i < mat.length; i++) {
				avall+=mat[i][c];
			}
		}
		
		if(!esticFora(mat, f, c)) //esquerra
		{
			for (int i = 0; i < c; i++) {
				esq+=mat[f][i];
			}
		}
		
		if(!esticFora(mat, f, c))
		{
			for (int i = c+1; i < mat[0].length; i++) {
				dreta+=mat[f][i];
			}
		}
		
		
		if(amunt>avall&&amunt>esq&&amunt>dreta&&amunt>posicio)
		{
			System.out.println("AMUNT");
		}
		else if(avall>amunt&&avall>dreta&&avall>esq&&avall>posicio)
		{
			System.out.println("AVALL");
		}
		else if(dreta>amunt&&dreta>avall&&dreta>esq&&dreta>posicio)
		{
			System.out.println("DRETA");
		}
		else if(esq>amunt&&esq>avall&&esq>dreta&&esq>posicio)
		{
			System.out.println("ESQUERRA");
		}
		else
		{
			System.out.println("NO SORTIR");
		}
		
	}
	private static boolean esticFora(int[][] mat, int f, int c) {

		if (f < 0 || c < 0 || f > mat.length - 1 || c > mat[0].length - 1) {
			return true;
		} else {

			return false;
		}
	}
}

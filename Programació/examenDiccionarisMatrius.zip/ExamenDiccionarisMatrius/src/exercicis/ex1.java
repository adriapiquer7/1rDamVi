package exercicis;

import java.util.Scanner;
import java.util.TreeMap;

public class ex1 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		TreeMap<String, Integer> dic = new TreeMap<>();
		
		String frase = sc.nextLine();
		String[] item = frase.split(" ");
		int contadorPle =0;
		int contadorBiut = 0;
		
		while(!frase.equals("FI"))
		{
			if(item[0].equals("ROBAR"))
			{
				if(dic.containsKey(item[1]))
				{
					int n =dic.get(item[1]);
					if(n<5)
					{
						dic.put(item[1], n+1);
					}
					else
					{
						dic.put(item[1], n);
					}
				}
				else
				{
					dic.put(item[1], 1);
				}
			}
			else if(item[0].equals("USAR"))
			{
				if(dic.containsKey(item[1]))
				{
					int v = dic.get(item[1]);
					if(v>0)
					{
						dic.put(item[1], v-1);
					}
					else
					{
						dic.put(item[1], 0);
					}
				}
			}
			
			frase=sc.nextLine();
			item = frase.split(" ");
		}
		
		for (Integer totalUsos : dic.values()) {
			if(totalUsos==5)
			{
				contadorPle++;
			}
			if(totalUsos==0)
			{
				contadorBiut++;
			}
		}
		
		System.out.println(dic);
		System.out.println("PLE: "+ contadorPle);
		System.out.println("BUIT: "+ contadorBiut);
	}

}

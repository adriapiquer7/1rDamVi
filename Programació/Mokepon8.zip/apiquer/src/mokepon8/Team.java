package mokepon8;

import java.util.ArrayList;

public class Team<T extends Mokepon> extends ArrayList<T>{
	@Override
    public boolean add(T m) {

        if(this.size() >= 6){
            return false;
        }

        return super.add(m);
    }
}

package mokepon8;

public class Arma extends Objecte implements Equipament{
	private int atacExtra;
	
	public Arma(String nom, int atacExtra) {
		super(nom);
		this.atacExtra = atacExtra;
	}

	public void utilitzar(Mokepon mok) {
		equipar((MokeponCapturat) mok);
	}

	@Override
	public void equipar(MokeponCapturat mok) {
		mok.setObjecteEquipat(this);
		mok.setAtk(mok.getAtk()+this.atacExtra);
	}

	@Override
	public void desequipar(MokeponCapturat mok) {
		mok.setObjecteEquipat(null);
		mok.setAtk(mok.getAtk()-this.atacExtra);
	}
}

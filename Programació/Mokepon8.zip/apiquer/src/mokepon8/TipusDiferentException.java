package mokepon8;

public class TipusDiferentException extends Exception {
 public TipusDiferentException(String missatge) {
     super(missatge);
 }
}

package mokepon8;

public enum TipusMokepon {
	FOC, AIGUA, PLANTA
}

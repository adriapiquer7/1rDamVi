package mokepon8;

public class MokeponMateixSexeException extends Exception {
    public MokeponMateixSexeException(String missatge) {
        super(missatge);
    }
}

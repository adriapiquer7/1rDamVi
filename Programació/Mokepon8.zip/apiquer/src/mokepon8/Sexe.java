package mokepon8;

public enum Sexe {
	MASCULI, FEMENI
}

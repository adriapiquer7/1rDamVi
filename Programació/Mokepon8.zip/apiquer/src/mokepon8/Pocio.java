package mokepon8;

public class Pocio extends Objecte {
	private int hp_curada;
	 
	Pocio(String nom, int hpCurada) {
        super(nom);
        this.hp_curada = hpCurada;
    }

	public void utilitzar(Mokepon mok) {
		if(super.getQuantitat()>=1)
		{
			if(!mok.isDebilitat())
			{
				if((mok.getHp_actual()+this.hp_curada)>mok.getHp_max())
				{
					mok.setHp_actual(mok.getHp_max());
					System.out.println("El pokemon: "+mok.getNom()+"! ha recuperado: "+this.hp_curada+"! ahora su vida es: "+mok.getHp_actual());
				}
				else
				{
					mok.setHp_actual(mok.getHp_actual()+this.hp_curada);
					System.out.println("El pokemon: "+mok.getNom()+"! ha recuperado: "+this.hp_curada+"! ahora su vida es: "+mok.getHp_actual());
				}
				super.Quantitat--;
			}
			else
			{
				System.out.println("No puedes curar a un pokemon debilitado!");
			}
		}
		else
		{
			System.out.println("No tienes mas "+super.getNom()+"!");
		}
	}

	public int getHp_curada() {
		return hp_curada;
	}

	public void setHp_curada(int hp_curada) {
		this.hp_curada = hp_curada;
	}
}

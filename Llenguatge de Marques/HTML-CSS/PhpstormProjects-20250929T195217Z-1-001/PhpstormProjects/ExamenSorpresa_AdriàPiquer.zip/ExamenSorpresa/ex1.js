const div = document.getElementById('div')
function boto(){
    if(div.classList===classe1)
    {
        div.classList.remove(classe1)
    }
    else{
        div.classList.add(classe1)
    }
}